﻿using System;
using System.Collections.Generic;
using System.Linq;
//using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Runtime.InteropServices;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.Reflection;
using System.Text.RegularExpressions;

namespace IverIDE
{
    static class Program
    {
        [DllImport("Shell32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern void SHChangeNotify(uint wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            AppDomain currentDomain = AppDomain.CurrentDomain;
            currentDomain.AssemblyResolve += new ResolveEventHandler(LoadFromSameFolder);

            Assembly LoadFromSameFolder(object sender, ResolveEventArgs reargs)
            {
                string folderPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"/dlls";
                string assemblyPath = Path.Combine(folderPath, new AssemblyName(reargs.Name).Name + ".dll");
                if (!File.Exists(assemblyPath)) return null;
                Assembly assembly = Assembly.LoadFrom(assemblyPath);
                return assembly;
            }



            if (args.Length == 0)
            {
                Application.Run(new Form1());

            }
            else
            {
                Application.Run(new Form1(args[0]));

            }

        }

        public static bool IsAssociated()
        {
            return (Registry.CurrentUser.OpenSubKey("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\.v", false) == null);
        }

        public static void Associate()
        {


            RegistryKey userClasses = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Classes\\", true);
            RegistryKey userWindows = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\", true);


            userClasses.CreateSubKey("Applications\\IverIDE.exe\\shell\\open\\command").SetValue("", Application.ExecutablePath + " \"%1\"");

            //Assotiate .v file

            userClasses.CreateSubKey("IverIDE.v").SetValue("", "Verilog file");
            userClasses.CreateSubKey("IverIDE.v\\DefaultIcon").SetValue("", Application.StartupPath + "\\IconVerilog.ico");
            userClasses.CreateSubKey("IverIDE.v\\shell\\open\\command").SetValue("", Application.ExecutablePath + " \"%1\"");
            userClasses.CreateSubKey(".v").SetValue("", "IverIDE.v");

            userWindows.OpenSubKey("CurrentVersion\\ApplicationAssociationToasts", true).SetValue("Applications\\IverIDE.exe_.v", 0);

            userWindows.CreateSubKey("Explorer\\FileExts\\.v");
            userWindows.CreateSubKey("Explorer\\FileExts\\.v\\OpenWithList").SetValue("a", "IverIDE.exe");
            userWindows.CreateSubKey("Explorer\\FileExts\\.v\\OpenWithProgids").SetValue("IverIDE.v", "0");

            //Assotiate .vpr file

            userClasses.CreateSubKey("IverIDE.vpr").SetValue("", "IverIDE Project");
            userClasses.CreateSubKey("IverIDE.vpr\\DefaultIcon").SetValue("", Application.StartupPath + "\\Icon.ico");
            userClasses.CreateSubKey("IverIDE.vpr\\shell\\open\\command").SetValue("", Application.ExecutablePath + " \"%1\"");
            userClasses.CreateSubKey(".vpr").SetValue("", "IverIDE.vpr");

            userWindows.OpenSubKey("CurrentVersion\\ApplicationAssociationToasts", true).SetValue("Applications\\IverIDE.exe_.vpr", 0);

            userWindows.CreateSubKey("Explorer\\FileExts\\.vpr");
            userWindows.CreateSubKey("Explorer\\FileExts\\.vpr\\OpenWithList").SetValue("a", "IverIDE.exe");
            userWindows.CreateSubKey("Explorer\\FileExts\\.vpr\\OpenWithProgids").SetValue("IverIDE.vpr", "0");




            userClasses.Close();
            userWindows.Close();


            SHChangeNotify(0x08000000, 0x0000, IntPtr.Zero, IntPtr.Zero);
            
        }


       

        public static void UpdateAssociation()
        {
            SHChangeNotify(0x08000000, 0x0000, IntPtr.Zero, IntPtr.Zero);
        }

    }
}
