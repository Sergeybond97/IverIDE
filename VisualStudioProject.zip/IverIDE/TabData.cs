﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;

namespace IverIDE
{
    class TabData
    {
        public bool documentChanged;

        public string tabName; // file name
        public string tabFilePath; // file path + name

        // Constructor
        public TabData()
        {
            documentChanged = false;
            tabName = "";
            tabFilePath = "";
        } 

    }
}
