﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IverIDE
{
    class ModuleData
    {
        public string moduleName;
        public string moduleFilePath;

        public ModuleData()
        {
            moduleName = "";
            moduleFilePath = "";
        }

    }
}
