﻿namespace IverIDE
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.mainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator10 = new System.Windows.Forms.ToolStripSeparator();
            this.commentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.findAndReplaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator9 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openDocumentationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainToolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonNew = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonOpen = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSave = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonSaveAs = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.ToolStripButtonUndo = new System.Windows.Forms.ToolStripButton();
            this.ToolStripButtonRedo = new System.Windows.Forms.ToolStripButton();
            this.ToolStripButtonCopy = new System.Windows.Forms.ToolStripButton();
            this.ToolStripButtonPaste = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonRun = new System.Windows.Forms.ToolStripSplitButton();
            this.toolStripRunMenuRunThis = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripButtonRunGTK = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonCloseTab = new System.Windows.Forms.ToolStripButton();
            this.mainTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.splitContainerConsole = new System.Windows.Forms.SplitContainer();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.buttonConsoleClear = new System.Windows.Forms.Button();
            this.consoleRichTextBox = new System.Windows.Forms.RichTextBox();
            this.rightPanel = new System.Windows.Forms.Panel();
            this.panelVerilogProject = new System.Windows.Forms.Panel();
            this.labelProjectHeader = new System.Windows.Forms.Label();
            this.textBoxProjectFile = new System.Windows.Forms.TextBox();
            this.labelProjectType = new System.Windows.Forms.Label();
            this.buttonRemoveFileFromList = new System.Windows.Forms.Button();
            this.labelAdditionalParams = new System.Windows.Forms.Label();
            this.labelOutputFileName = new System.Windows.Forms.Label();
            this.textBoxAdditionalParams = new System.Windows.Forms.TextBox();
            this.buttonAddFileToList = new System.Windows.Forms.Button();
            this.checkBoxUsingAdditionalParams = new System.Windows.Forms.CheckBox();
            this.textBoxOutputFileName = new System.Windows.Forms.TextBox();
            this.textBoxTopModuleName = new System.Windows.Forms.TextBox();
            this.labelFileList = new System.Windows.Forms.Label();
            this.labelTopModule = new System.Windows.Forms.Label();
            this.listBoxFileList = new System.Windows.Forms.ListBox();
            this.labelProjectPath = new System.Windows.Forms.Label();
            this.checkBoxUsingTopModule = new System.Windows.Forms.CheckBox();
            this.checkBoxHaveDump = new System.Windows.Forms.CheckBox();
            this.textBoxDumpFileName = new System.Windows.Forms.TextBox();
            this.labelDumpFileName = new System.Windows.Forms.Label();
            this.panelNewProjectType = new System.Windows.Forms.Panel();
            this.buttonNewProjectVHDL = new System.Windows.Forms.Button();
            this.buttonNewProjectVerilog = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonSaveAsProject = new System.Windows.Forms.Button();
            this.labelEndProjectPanel = new System.Windows.Forms.Label();
            this.buttonRunJustThis = new System.Windows.Forms.Button();
            this.buttonNewProject = new System.Windows.Forms.Button();
            this.buttonOpenProject = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.browsePrjFolderDialog = new System.Windows.Forms.FolderBrowserDialog();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.mainMenuStrip.SuspendLayout();
            this.mainToolStrip.SuspendLayout();
            this.mainTableLayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerConsole)).BeginInit();
            this.splitContainerConsole.Panel1.SuspendLayout();
            this.splitContainerConsole.Panel2.SuspendLayout();
            this.splitContainerConsole.SuspendLayout();
            this.rightPanel.SuspendLayout();
            this.panelVerilogProject.SuspendLayout();
            this.panelNewProjectType.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainMenuStrip
            // 
            this.mainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.programToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.mainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.mainMenuStrip.Name = "mainMenuStrip";
            this.mainMenuStrip.Size = new System.Drawing.Size(1008, 24);
            this.mainMenuStrip.TabIndex = 1;
            this.mainMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator1,
            this.toolStripSeparator4,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.newToolStripMenuItem.Text = "New";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.saveAsToolStripMenuItem.Text = "Save as";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(109, 6);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(109, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.toolStripSeparator2,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.toolStripSeparator3,
            this.selectAllToolStripMenuItem,
            this.toolStripSeparator10,
            this.commentToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.undoToolStripMenuItem.Text = "Undo";
            this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.redoToolStripMenuItem.Text = "Redo";
            this.redoToolStripMenuItem.Click += new System.EventHandler(this.redoToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(125, 6);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(125, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.selectAllToolStripMenuItem.Text = "Select all";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // toolStripSeparator10
            // 
            this.toolStripSeparator10.Name = "toolStripSeparator10";
            this.toolStripSeparator10.Size = new System.Drawing.Size(125, 6);
            // 
            // commentToolStripMenuItem
            // 
            this.commentToolStripMenuItem.Enabled = false;
            this.commentToolStripMenuItem.Name = "commentToolStripMenuItem";
            this.commentToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.commentToolStripMenuItem.Text = "Comment";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.findAndReplaceToolStripMenuItem});
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.searchToolStripMenuItem.Text = "Search";
            // 
            // findAndReplaceToolStripMenuItem
            // 
            this.findAndReplaceToolStripMenuItem.Name = "findAndReplaceToolStripMenuItem";
            this.findAndReplaceToolStripMenuItem.Size = new System.Drawing.Size(161, 22);
            this.findAndReplaceToolStripMenuItem.Text = "Find and replace";
            this.findAndReplaceToolStripMenuItem.Click += new System.EventHandler(this.findAndReplaceToolStripMenuItem_Click);
            // 
            // programToolStripMenuItem
            // 
            this.programToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem,
            this.toolStripSeparator9,
            this.aboutToolStripMenuItem});
            this.programToolStripMenuItem.Name = "programToolStripMenuItem";
            this.programToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.programToolStripMenuItem.Text = "Program";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // toolStripSeparator9
            // 
            this.toolStripSeparator9.Name = "toolStripSeparator9";
            this.toolStripSeparator9.Size = new System.Drawing.Size(113, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(116, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openDocumentationToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // openDocumentationToolStripMenuItem
            // 
            this.openDocumentationToolStripMenuItem.Enabled = false;
            this.openDocumentationToolStripMenuItem.Name = "openDocumentationToolStripMenuItem";
            this.openDocumentationToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.openDocumentationToolStripMenuItem.Text = "Open documentation";
            // 
            // mainToolStrip
            // 
            this.mainToolStrip.ImageScalingSize = new System.Drawing.Size(30, 30);
            this.mainToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonNew,
            this.toolStripButtonOpen,
            this.toolStripButtonSave,
            this.toolStripButtonSaveAs,
            this.toolStripSeparator8,
            this.ToolStripButtonUndo,
            this.ToolStripButtonRedo,
            this.ToolStripButtonCopy,
            this.ToolStripButtonPaste,
            this.toolStripSeparator5,
            this.toolStripButtonRun,
            this.toolStripButtonRunGTK,
            this.toolStripLabel1,
            this.toolStripSeparator7,
            this.toolStripButtonCloseTab});
            this.mainToolStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.mainToolStrip.Location = new System.Drawing.Point(0, 24);
            this.mainToolStrip.Name = "mainToolStrip";
            this.mainToolStrip.Size = new System.Drawing.Size(1008, 52);
            this.mainToolStrip.TabIndex = 2;
            this.mainToolStrip.Text = "toolStrip1";
            // 
            // toolStripButtonNew
            // 
            this.toolStripButtonNew.AutoSize = false;
            this.toolStripButtonNew.Image = global::IverIDE.Properties.Resources.NewIcon;
            this.toolStripButtonNew.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonNew.Name = "toolStripButtonNew";
            this.toolStripButtonNew.Size = new System.Drawing.Size(49, 49);
            this.toolStripButtonNew.Text = "New";
            this.toolStripButtonNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButtonNew.Click += new System.EventHandler(this.toolStripButtonNew_Click);
            // 
            // toolStripButtonOpen
            // 
            this.toolStripButtonOpen.AutoSize = false;
            this.toolStripButtonOpen.Image = global::IverIDE.Properties.Resources.OpenIcon;
            this.toolStripButtonOpen.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonOpen.Name = "toolStripButtonOpen";
            this.toolStripButtonOpen.Size = new System.Drawing.Size(49, 49);
            this.toolStripButtonOpen.Text = "Open";
            this.toolStripButtonOpen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButtonOpen.Click += new System.EventHandler(this.toolStripButtonOpen_Click);
            // 
            // toolStripButtonSave
            // 
            this.toolStripButtonSave.AutoSize = false;
            this.toolStripButtonSave.Image = global::IverIDE.Properties.Resources.SaveIcon;
            this.toolStripButtonSave.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSave.Name = "toolStripButtonSave";
            this.toolStripButtonSave.Size = new System.Drawing.Size(49, 49);
            this.toolStripButtonSave.Text = "Save";
            this.toolStripButtonSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButtonSave.ToolTipText = "Save";
            this.toolStripButtonSave.Click += new System.EventHandler(this.toolStripButtonSave_Click_1);
            // 
            // toolStripButtonSaveAs
            // 
            this.toolStripButtonSaveAs.AutoSize = false;
            this.toolStripButtonSaveAs.Image = global::IverIDE.Properties.Resources.SaveAsIcon;
            this.toolStripButtonSaveAs.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonSaveAs.Name = "toolStripButtonSaveAs";
            this.toolStripButtonSaveAs.Size = new System.Drawing.Size(49, 49);
            this.toolStripButtonSaveAs.Text = "Save as";
            this.toolStripButtonSaveAs.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButtonSaveAs.ToolTipText = "Save as";
            this.toolStripButtonSaveAs.Click += new System.EventHandler(this.toolStripButtonSave_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.AutoSize = false;
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(6, 49);
            // 
            // ToolStripButtonUndo
            // 
            this.ToolStripButtonUndo.AutoSize = false;
            this.ToolStripButtonUndo.Image = global::IverIDE.Properties.Resources.UndoIcon;
            this.ToolStripButtonUndo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButtonUndo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ToolStripButtonUndo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButtonUndo.Name = "ToolStripButtonUndo";
            this.ToolStripButtonUndo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ToolStripButtonUndo.Size = new System.Drawing.Size(60, 25);
            this.ToolStripButtonUndo.Text = "Undo";
            this.ToolStripButtonUndo.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // ToolStripButtonRedo
            // 
            this.ToolStripButtonRedo.AutoSize = false;
            this.ToolStripButtonRedo.Image = global::IverIDE.Properties.Resources.RedoIcon;
            this.ToolStripButtonRedo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButtonRedo.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ToolStripButtonRedo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButtonRedo.Margin = new System.Windows.Forms.Padding(-60, 25, 0, 0);
            this.ToolStripButtonRedo.Name = "ToolStripButtonRedo";
            this.ToolStripButtonRedo.Size = new System.Drawing.Size(60, 24);
            this.ToolStripButtonRedo.Text = "Redo";
            this.ToolStripButtonRedo.Click += new System.EventHandler(this.toolStripButton3_Click);
            // 
            // ToolStripButtonCopy
            // 
            this.ToolStripButtonCopy.AutoSize = false;
            this.ToolStripButtonCopy.Image = global::IverIDE.Properties.Resources.CopyIcon;
            this.ToolStripButtonCopy.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButtonCopy.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ToolStripButtonCopy.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButtonCopy.Name = "ToolStripButtonCopy";
            this.ToolStripButtonCopy.Size = new System.Drawing.Size(60, 25);
            this.ToolStripButtonCopy.Text = "Copy";
            this.ToolStripButtonCopy.Click += new System.EventHandler(this.toolStripButton4_Click);
            // 
            // ToolStripButtonPaste
            // 
            this.ToolStripButtonPaste.AutoSize = false;
            this.ToolStripButtonPaste.Image = global::IverIDE.Properties.Resources.PasteIcon;
            this.ToolStripButtonPaste.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ToolStripButtonPaste.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.ToolStripButtonPaste.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.ToolStripButtonPaste.Margin = new System.Windows.Forms.Padding(-60, 25, 0, 2);
            this.ToolStripButtonPaste.Name = "ToolStripButtonPaste";
            this.ToolStripButtonPaste.Size = new System.Drawing.Size(60, 24);
            this.ToolStripButtonPaste.Text = "Paste";
            this.ToolStripButtonPaste.Click += new System.EventHandler(this.toolStripButton2_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.AutoSize = false;
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripButtonRun
            // 
            this.toolStripButtonRun.AutoSize = false;
            this.toolStripButtonRun.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripRunMenuRunThis});
            this.toolStripButtonRun.Image = global::IverIDE.Properties.Resources.PlayIcon;
            this.toolStripButtonRun.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRun.Name = "toolStripButtonRun";
            this.toolStripButtonRun.Size = new System.Drawing.Size(65, 49);
            this.toolStripButtonRun.Text = "Run";
            this.toolStripButtonRun.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButtonRun.ButtonClick += new System.EventHandler(this.toolStripButtonRun_ButtonClick);
            // 
            // toolStripRunMenuRunThis
            // 
            this.toolStripRunMenuRunThis.Image = global::IverIDE.Properties.Resources.Play2Icon;
            this.toolStripRunMenuRunThis.Name = "toolStripRunMenuRunThis";
            this.toolStripRunMenuRunThis.Size = new System.Drawing.Size(158, 22);
            this.toolStripRunMenuRunThis.Text = "Run just this file";
            this.toolStripRunMenuRunThis.Click += new System.EventHandler(this.toolStripRunMenuRunThis_Click);
            // 
            // toolStripButtonRunGTK
            // 
            this.toolStripButtonRunGTK.AutoSize = false;
            this.toolStripButtonRunGTK.Image = global::IverIDE.Properties.Resources.WaveIcon;
            this.toolStripButtonRunGTK.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRunGTK.Name = "toolStripButtonRunGTK";
            this.toolStripButtonRunGTK.Size = new System.Drawing.Size(59, 49);
            this.toolStripButtonRunGTK.Text = "Run GTK";
            this.toolStripButtonRunGTK.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButtonRunGTK.Click += new System.EventHandler(this.toolStripButtonRunGTK_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(67, 15);
            this.toolStripLabel1.Text = "                    ";
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.AutoSize = false;
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(6, 49);
            // 
            // toolStripButtonCloseTab
            // 
            this.toolStripButtonCloseTab.Image = global::IverIDE.Properties.Resources.DeleteIcon;
            this.toolStripButtonCloseTab.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonCloseTab.Name = "toolStripButtonCloseTab";
            this.toolStripButtonCloseTab.Size = new System.Drawing.Size(60, 49);
            this.toolStripButtonCloseTab.Text = "Close tab";
            this.toolStripButtonCloseTab.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.toolStripButtonCloseTab.Click += new System.EventHandler(this.toolStripButtonCloseTab_Click);
            // 
            // mainTableLayoutPanel
            // 
            this.mainTableLayoutPanel.ColumnCount = 2;
            this.mainTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainTableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.mainTableLayoutPanel.Controls.Add(this.splitContainerConsole, 0, 0);
            this.mainTableLayoutPanel.Controls.Add(this.rightPanel, 1, 0);
            this.mainTableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainTableLayoutPanel.Location = new System.Drawing.Point(0, 76);
            this.mainTableLayoutPanel.Name = "mainTableLayoutPanel";
            this.mainTableLayoutPanel.RowCount = 1;
            this.mainTableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.mainTableLayoutPanel.Size = new System.Drawing.Size(1008, 445);
            this.mainTableLayoutPanel.TabIndex = 3;
            // 
            // splitContainerConsole
            // 
            this.splitContainerConsole.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerConsole.Location = new System.Drawing.Point(3, 3);
            this.splitContainerConsole.Name = "splitContainerConsole";
            this.splitContainerConsole.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainerConsole.Panel1
            // 
            this.splitContainerConsole.Panel1.Controls.Add(this.tabControl);
            // 
            // splitContainerConsole.Panel2
            // 
            this.splitContainerConsole.Panel2.Controls.Add(this.buttonConsoleClear);
            this.splitContainerConsole.Panel2.Controls.Add(this.consoleRichTextBox);
            this.splitContainerConsole.Size = new System.Drawing.Size(802, 439);
            this.splitContainerConsole.SplitterDistance = 309;
            this.splitContainerConsole.TabIndex = 4;
            // 
            // tabControl
            // 
            this.tabControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Location = new System.Drawing.Point(0, 0);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(802, 309);
            this.tabControl.TabIndex = 0;
            this.tabControl.SelectedIndexChanged += new System.EventHandler(this.tabControl_SelectedIndexChanged);
            // 
            // buttonConsoleClear
            // 
            this.buttonConsoleClear.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonConsoleClear.Location = new System.Drawing.Point(741, 2);
            this.buttonConsoleClear.Name = "buttonConsoleClear";
            this.buttonConsoleClear.Size = new System.Drawing.Size(39, 22);
            this.buttonConsoleClear.TabIndex = 2;
            this.buttonConsoleClear.Text = "Clear";
            this.buttonConsoleClear.UseVisualStyleBackColor = true;
            this.buttonConsoleClear.Click += new System.EventHandler(this.buttonConsoleClear_Click);
            // 
            // consoleRichTextBox
            // 
            this.consoleRichTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.consoleRichTextBox.DetectUrls = false;
            this.consoleRichTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.consoleRichTextBox.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.consoleRichTextBox.Location = new System.Drawing.Point(0, 0);
            this.consoleRichTextBox.Name = "consoleRichTextBox";
            this.consoleRichTextBox.ReadOnly = true;
            this.consoleRichTextBox.Size = new System.Drawing.Size(802, 126);
            this.consoleRichTextBox.TabIndex = 1;
            this.consoleRichTextBox.Text = "";
            this.consoleRichTextBox.WordWrap = false;
            // 
            // rightPanel
            // 
            this.rightPanel.AutoScroll = true;
            this.rightPanel.BackColor = System.Drawing.SystemColors.Control;
            this.rightPanel.Controls.Add(this.panelVerilogProject);
            this.rightPanel.Controls.Add(this.panelNewProjectType);
            this.rightPanel.Controls.Add(this.label2);
            this.rightPanel.Controls.Add(this.buttonSaveAsProject);
            this.rightPanel.Controls.Add(this.labelEndProjectPanel);
            this.rightPanel.Controls.Add(this.buttonRunJustThis);
            this.rightPanel.Controls.Add(this.buttonNewProject);
            this.rightPanel.Controls.Add(this.buttonOpenProject);
            this.rightPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rightPanel.Location = new System.Drawing.Point(811, 3);
            this.rightPanel.Name = "rightPanel";
            this.rightPanel.Size = new System.Drawing.Size(194, 439);
            this.rightPanel.TabIndex = 2;
            // 
            // panelVerilogProject
            // 
            this.panelVerilogProject.Controls.Add(this.labelProjectHeader);
            this.panelVerilogProject.Controls.Add(this.textBoxProjectFile);
            this.panelVerilogProject.Controls.Add(this.labelProjectType);
            this.panelVerilogProject.Controls.Add(this.buttonRemoveFileFromList);
            this.panelVerilogProject.Controls.Add(this.labelAdditionalParams);
            this.panelVerilogProject.Controls.Add(this.labelOutputFileName);
            this.panelVerilogProject.Controls.Add(this.textBoxAdditionalParams);
            this.panelVerilogProject.Controls.Add(this.buttonAddFileToList);
            this.panelVerilogProject.Controls.Add(this.checkBoxUsingAdditionalParams);
            this.panelVerilogProject.Controls.Add(this.textBoxOutputFileName);
            this.panelVerilogProject.Controls.Add(this.textBoxTopModuleName);
            this.panelVerilogProject.Controls.Add(this.labelFileList);
            this.panelVerilogProject.Controls.Add(this.labelTopModule);
            this.panelVerilogProject.Controls.Add(this.listBoxFileList);
            this.panelVerilogProject.Controls.Add(this.labelProjectPath);
            this.panelVerilogProject.Controls.Add(this.checkBoxUsingTopModule);
            this.panelVerilogProject.Controls.Add(this.checkBoxHaveDump);
            this.panelVerilogProject.Controls.Add(this.textBoxDumpFileName);
            this.panelVerilogProject.Controls.Add(this.labelDumpFileName);
            this.panelVerilogProject.Location = new System.Drawing.Point(3, 204);
            this.panelVerilogProject.Name = "panelVerilogProject";
            this.panelVerilogProject.Size = new System.Drawing.Size(164, 685);
            this.panelVerilogProject.TabIndex = 28;
            // 
            // labelProjectHeader
            // 
            this.labelProjectHeader.AutoSize = true;
            this.labelProjectHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProjectHeader.Location = new System.Drawing.Point(3, 11);
            this.labelProjectHeader.Name = "labelProjectHeader";
            this.labelProjectHeader.Size = new System.Drawing.Size(58, 20);
            this.labelProjectHeader.TabIndex = 0;
            this.labelProjectHeader.Text = "Project";
            // 
            // textBoxProjectFile
            // 
            this.textBoxProjectFile.Location = new System.Drawing.Point(3, 105);
            this.textBoxProjectFile.Name = "textBoxProjectFile";
            this.textBoxProjectFile.ReadOnly = true;
            this.textBoxProjectFile.Size = new System.Drawing.Size(160, 20);
            this.textBoxProjectFile.TabIndex = 2;
            // 
            // labelProjectType
            // 
            this.labelProjectType.AutoSize = true;
            this.labelProjectType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelProjectType.Location = new System.Drawing.Point(3, 47);
            this.labelProjectType.Name = "labelProjectType";
            this.labelProjectType.Size = new System.Drawing.Size(43, 20);
            this.labelProjectType.TabIndex = 26;
            this.labelProjectType.Text = "Type";
            // 
            // buttonRemoveFileFromList
            // 
            this.buttonRemoveFileFromList.Image = global::IverIDE.Properties.Resources.RemoveIcon1;
            this.buttonRemoveFileFromList.Location = new System.Drawing.Point(88, 313);
            this.buttonRemoveFileFromList.Name = "buttonRemoveFileFromList";
            this.buttonRemoveFileFromList.Size = new System.Drawing.Size(75, 33);
            this.buttonRemoveFileFromList.TabIndex = 24;
            this.buttonRemoveFileFromList.Text = "Remove";
            this.buttonRemoveFileFromList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonRemoveFileFromList.UseVisualStyleBackColor = true;
            this.buttonRemoveFileFromList.Click += new System.EventHandler(this.buttonRemoveFileFromList_Click);
            // 
            // labelAdditionalParams
            // 
            this.labelAdditionalParams.AutoSize = true;
            this.labelAdditionalParams.Location = new System.Drawing.Point(3, 576);
            this.labelAdditionalParams.Name = "labelAdditionalParams";
            this.labelAdditionalParams.Size = new System.Drawing.Size(108, 13);
            this.labelAdditionalParams.TabIndex = 19;
            this.labelAdditionalParams.Text = "Additional parameters";
            // 
            // labelOutputFileName
            // 
            this.labelOutputFileName.AutoSize = true;
            this.labelOutputFileName.Location = new System.Drawing.Point(3, 144);
            this.labelOutputFileName.Name = "labelOutputFileName";
            this.labelOutputFileName.Size = new System.Drawing.Size(84, 13);
            this.labelOutputFileName.TabIndex = 3;
            this.labelOutputFileName.Text = "Output file name";
            // 
            // textBoxAdditionalParams
            // 
            this.textBoxAdditionalParams.Enabled = false;
            this.textBoxAdditionalParams.Location = new System.Drawing.Point(3, 592);
            this.textBoxAdditionalParams.Name = "textBoxAdditionalParams";
            this.textBoxAdditionalParams.Size = new System.Drawing.Size(160, 20);
            this.textBoxAdditionalParams.TabIndex = 18;
            this.textBoxAdditionalParams.TextChanged += new System.EventHandler(this.textBoxAdditionalParams_TextChanged);
            // 
            // buttonAddFileToList
            // 
            this.buttonAddFileToList.Image = global::IverIDE.Properties.Resources.AddIcon1;
            this.buttonAddFileToList.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAddFileToList.Location = new System.Drawing.Point(3, 313);
            this.buttonAddFileToList.Name = "buttonAddFileToList";
            this.buttonAddFileToList.Size = new System.Drawing.Size(75, 33);
            this.buttonAddFileToList.TabIndex = 23;
            this.buttonAddFileToList.Text = "Add";
            this.buttonAddFileToList.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonAddFileToList.UseVisualStyleBackColor = true;
            this.buttonAddFileToList.Click += new System.EventHandler(this.buttonAddFileToList_Click);
            // 
            // checkBoxUsingAdditionalParams
            // 
            this.checkBoxUsingAdditionalParams.AutoSize = true;
            this.checkBoxUsingAdditionalParams.Location = new System.Drawing.Point(3, 547);
            this.checkBoxUsingAdditionalParams.Name = "checkBoxUsingAdditionalParams";
            this.checkBoxUsingAdditionalParams.Size = new System.Drawing.Size(156, 17);
            this.checkBoxUsingAdditionalParams.TabIndex = 17;
            this.checkBoxUsingAdditionalParams.Text = "Using additional parameters";
            this.checkBoxUsingAdditionalParams.UseVisualStyleBackColor = true;
            this.checkBoxUsingAdditionalParams.CheckedChanged += new System.EventHandler(this.checkBoxUsingAdditionalParams_CheckedChanged);
            // 
            // textBoxOutputFileName
            // 
            this.textBoxOutputFileName.Location = new System.Drawing.Point(3, 160);
            this.textBoxOutputFileName.Name = "textBoxOutputFileName";
            this.textBoxOutputFileName.Size = new System.Drawing.Size(160, 20);
            this.textBoxOutputFileName.TabIndex = 4;
            this.textBoxOutputFileName.TextChanged += new System.EventHandler(this.textBoxOutputFileName_TextChanged);
            // 
            // textBoxTopModuleName
            // 
            this.textBoxTopModuleName.Enabled = false;
            this.textBoxTopModuleName.Location = new System.Drawing.Point(3, 507);
            this.textBoxTopModuleName.Name = "textBoxTopModuleName";
            this.textBoxTopModuleName.Size = new System.Drawing.Size(160, 20);
            this.textBoxTopModuleName.TabIndex = 16;
            this.textBoxTopModuleName.TextChanged += new System.EventHandler(this.textBoxTopModuleName_TextChanged);
            // 
            // labelFileList
            // 
            this.labelFileList.AutoSize = true;
            this.labelFileList.Location = new System.Drawing.Point(3, 196);
            this.labelFileList.Name = "labelFileList";
            this.labelFileList.Size = new System.Drawing.Size(38, 13);
            this.labelFileList.TabIndex = 22;
            this.labelFileList.Text = "File list";
            // 
            // labelTopModule
            // 
            this.labelTopModule.AutoSize = true;
            this.labelTopModule.Location = new System.Drawing.Point(3, 491);
            this.labelTopModule.Name = "labelTopModule";
            this.labelTopModule.Size = new System.Drawing.Size(92, 13);
            this.labelTopModule.TabIndex = 15;
            this.labelTopModule.Text = "Top module name";
            // 
            // listBoxFileList
            // 
            this.listBoxFileList.FormattingEnabled = true;
            this.listBoxFileList.Location = new System.Drawing.Point(3, 212);
            this.listBoxFileList.Name = "listBoxFileList";
            this.listBoxFileList.ScrollAlwaysVisible = true;
            this.listBoxFileList.Size = new System.Drawing.Size(160, 95);
            this.listBoxFileList.TabIndex = 21;
            // 
            // labelProjectPath
            // 
            this.labelProjectPath.AutoSize = true;
            this.labelProjectPath.Location = new System.Drawing.Point(3, 89);
            this.labelProjectPath.Name = "labelProjectPath";
            this.labelProjectPath.Size = new System.Drawing.Size(64, 13);
            this.labelProjectPath.TabIndex = 11;
            this.labelProjectPath.Text = "Project path";
            // 
            // checkBoxUsingTopModule
            // 
            this.checkBoxUsingTopModule.AutoSize = true;
            this.checkBoxUsingTopModule.Location = new System.Drawing.Point(3, 461);
            this.checkBoxUsingTopModule.Name = "checkBoxUsingTopModule";
            this.checkBoxUsingTopModule.Size = new System.Drawing.Size(108, 17);
            this.checkBoxUsingTopModule.TabIndex = 12;
            this.checkBoxUsingTopModule.Text = "Using top module";
            this.checkBoxUsingTopModule.UseVisualStyleBackColor = true;
            this.checkBoxUsingTopModule.CheckedChanged += new System.EventHandler(this.checkBoxUsingTopModule_CheckedChanged);
            // 
            // checkBoxHaveDump
            // 
            this.checkBoxHaveDump.AutoSize = true;
            this.checkBoxHaveDump.Location = new System.Drawing.Point(3, 374);
            this.checkBoxHaveDump.Name = "checkBoxHaveDump";
            this.checkBoxHaveDump.Size = new System.Drawing.Size(139, 17);
            this.checkBoxHaveDump.TabIndex = 5;
            this.checkBoxHaveDump.Text = "Open dump file after run";
            this.checkBoxHaveDump.UseVisualStyleBackColor = true;
            this.checkBoxHaveDump.CheckedChanged += new System.EventHandler(this.checkBoxHaveDump_CheckedChanged);
            // 
            // textBoxDumpFileName
            // 
            this.textBoxDumpFileName.Enabled = false;
            this.textBoxDumpFileName.Location = new System.Drawing.Point(3, 420);
            this.textBoxDumpFileName.Name = "textBoxDumpFileName";
            this.textBoxDumpFileName.Size = new System.Drawing.Size(160, 20);
            this.textBoxDumpFileName.TabIndex = 6;
            this.textBoxDumpFileName.TextChanged += new System.EventHandler(this.textBoxDumpFileName_TextChanged);
            // 
            // labelDumpFileName
            // 
            this.labelDumpFileName.AutoSize = true;
            this.labelDumpFileName.Location = new System.Drawing.Point(3, 404);
            this.labelDumpFileName.Name = "labelDumpFileName";
            this.labelDumpFileName.Size = new System.Drawing.Size(75, 13);
            this.labelDumpFileName.TabIndex = 7;
            this.labelDumpFileName.Text = "Dump file path";
            // 
            // panelNewProjectType
            // 
            this.panelNewProjectType.Controls.Add(this.buttonNewProjectVHDL);
            this.panelNewProjectType.Controls.Add(this.buttonNewProjectVerilog);
            this.panelNewProjectType.Enabled = false;
            this.panelNewProjectType.Location = new System.Drawing.Point(3, 20);
            this.panelNewProjectType.Name = "panelNewProjectType";
            this.panelNewProjectType.Size = new System.Drawing.Size(164, 160);
            this.panelNewProjectType.TabIndex = 27;
            this.panelNewProjectType.Visible = false;
            // 
            // buttonNewProjectVHDL
            // 
            this.buttonNewProjectVHDL.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonNewProjectVHDL.Image = global::IverIDE.Properties.Resources.NewIcon;
            this.buttonNewProjectVHDL.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNewProjectVHDL.Location = new System.Drawing.Point(2, 81);
            this.buttonNewProjectVHDL.Name = "buttonNewProjectVHDL";
            this.buttonNewProjectVHDL.Size = new System.Drawing.Size(160, 50);
            this.buttonNewProjectVHDL.TabIndex = 11;
            this.buttonNewProjectVHDL.Text = "New VHDL project";
            this.buttonNewProjectVHDL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonNewProjectVHDL.UseVisualStyleBackColor = true;
            this.buttonNewProjectVHDL.Click += new System.EventHandler(this.buttonNewProjectVHDL_Click);
            // 
            // buttonNewProjectVerilog
            // 
            this.buttonNewProjectVerilog.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonNewProjectVerilog.Image = global::IverIDE.Properties.Resources.NewIcon;
            this.buttonNewProjectVerilog.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNewProjectVerilog.Location = new System.Drawing.Point(2, 25);
            this.buttonNewProjectVerilog.Name = "buttonNewProjectVerilog";
            this.buttonNewProjectVerilog.Size = new System.Drawing.Size(160, 50);
            this.buttonNewProjectVerilog.TabIndex = 10;
            this.buttonNewProjectVerilog.Text = "New Verilog project";
            this.buttonNewProjectVerilog.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonNewProjectVerilog.UseVisualStyleBackColor = true;
            this.buttonNewProjectVerilog.Click += new System.EventHandler(this.buttonNewProjectVerilog_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(163, 13);
            this.label2.TabIndex = 25;
            this.label2.Text = "----------------------------------------------------";
            // 
            // buttonSaveAsProject
            // 
            this.buttonSaveAsProject.Enabled = false;
            this.buttonSaveAsProject.Image = global::IverIDE.Properties.Resources.SaveAsIcon;
            this.buttonSaveAsProject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonSaveAsProject.Location = new System.Drawing.Point(5, 131);
            this.buttonSaveAsProject.Name = "buttonSaveAsProject";
            this.buttonSaveAsProject.Size = new System.Drawing.Size(160, 50);
            this.buttonSaveAsProject.TabIndex = 20;
            this.buttonSaveAsProject.Text = "Save project as";
            this.buttonSaveAsProject.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonSaveAsProject.UseVisualStyleBackColor = true;
            this.buttonSaveAsProject.Visible = false;
            this.buttonSaveAsProject.Click += new System.EventHandler(this.buttonSaveAsProject_Click);
            // 
            // labelEndProjectPanel
            // 
            this.labelEndProjectPanel.AutoSize = true;
            this.labelEndProjectPanel.Location = new System.Drawing.Point(47, 931);
            this.labelEndProjectPanel.Name = "labelEndProjectPanel";
            this.labelEndProjectPanel.Size = new System.Drawing.Size(0, 13);
            this.labelEndProjectPanel.TabIndex = 13;
            // 
            // buttonRunJustThis
            // 
            this.buttonRunJustThis.Image = global::IverIDE.Properties.Resources.Play2Icon;
            this.buttonRunJustThis.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonRunJustThis.Location = new System.Drawing.Point(5, 131);
            this.buttonRunJustThis.Name = "buttonRunJustThis";
            this.buttonRunJustThis.Size = new System.Drawing.Size(161, 50);
            this.buttonRunJustThis.TabIndex = 10;
            this.buttonRunJustThis.Text = "Run just this file";
            this.buttonRunJustThis.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonRunJustThis.UseVisualStyleBackColor = true;
            this.buttonRunJustThis.Click += new System.EventHandler(this.buttonRunJustThis_Click);
            // 
            // buttonNewProject
            // 
            this.buttonNewProject.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.buttonNewProject.Image = global::IverIDE.Properties.Resources.NewIcon;
            this.buttonNewProject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonNewProject.Location = new System.Drawing.Point(5, 20);
            this.buttonNewProject.Name = "buttonNewProject";
            this.buttonNewProject.Size = new System.Drawing.Size(160, 50);
            this.buttonNewProject.TabIndex = 9;
            this.buttonNewProject.Text = "New project";
            this.buttonNewProject.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonNewProject.UseVisualStyleBackColor = true;
            this.buttonNewProject.Click += new System.EventHandler(this.buttonNewProject_Click);
            // 
            // buttonOpenProject
            // 
            this.buttonOpenProject.Image = global::IverIDE.Properties.Resources.OpenIcon;
            this.buttonOpenProject.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonOpenProject.Location = new System.Drawing.Point(5, 76);
            this.buttonOpenProject.Name = "buttonOpenProject";
            this.buttonOpenProject.Size = new System.Drawing.Size(160, 50);
            this.buttonOpenProject.TabIndex = 8;
            this.buttonOpenProject.Text = "Open project";
            this.buttonOpenProject.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonOpenProject.UseVisualStyleBackColor = true;
            this.buttonOpenProject.Click += new System.EventHandler(this.buttonOpenProject_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.Filter = "Verilog file (*.v)|*.v|All files (*.*)|*.*";
            // 
            // saveFileDialog
            // 
            this.saveFileDialog.Filter = "Verilog file (*.v)|*.v|All files (*.*)|*.*";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 521);
            this.Controls.Add(this.mainTableLayoutPanel);
            this.Controls.Add(this.mainToolStrip);
            this.Controls.Add(this.mainMenuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mainMenuStrip;
            this.MinimumSize = new System.Drawing.Size(768, 560);
            this.Name = "Form1";
            this.Text = "Iver IDE 0.1.8";
            this.mainMenuStrip.ResumeLayout(false);
            this.mainMenuStrip.PerformLayout();
            this.mainToolStrip.ResumeLayout(false);
            this.mainToolStrip.PerformLayout();
            this.mainTableLayoutPanel.ResumeLayout(false);
            this.splitContainerConsole.Panel1.ResumeLayout(false);
            this.splitContainerConsole.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerConsole)).EndInit();
            this.splitContainerConsole.ResumeLayout(false);
            this.rightPanel.ResumeLayout(false);
            this.rightPanel.PerformLayout();
            this.panelVerilogProject.ResumeLayout(false);
            this.panelVerilogProject.PerformLayout();
            this.panelNewProjectType.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip mainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStrip mainToolStrip;
        private System.Windows.Forms.ToolStripButton toolStripButtonNew;
        private System.Windows.Forms.ToolStripButton toolStripButtonOpen;
        private System.Windows.Forms.ToolStripButton toolStripButtonSaveAs;
        private System.Windows.Forms.TableLayoutPanel mainTableLayoutPanel;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripButton toolStripButtonCloseTab;
        private System.Windows.Forms.SaveFileDialog saveFileDialog;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton ToolStripButtonUndo;
        private System.Windows.Forms.ToolStripButton ToolStripButtonRedo;
        private System.Windows.Forms.ToolStripButton ToolStripButtonCopy;
        private System.Windows.Forms.ToolStripButton ToolStripButtonPaste;
        private System.Windows.Forms.ToolStripMenuItem programToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator9;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator10;
        private System.Windows.Forms.ToolStripMenuItem commentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem findAndReplaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openDocumentationToolStripMenuItem;
        private System.Windows.Forms.FolderBrowserDialog browsePrjFolderDialog;
        private System.Windows.Forms.ToolStripSplitButton toolStripButtonRun;
        private System.Windows.Forms.ToolStripMenuItem toolStripRunMenuRunThis;
        private System.Windows.Forms.ToolStripButton toolStripButtonRunGTK;
        private System.Windows.Forms.ToolStripButton toolStripButtonSave;
        private System.Windows.Forms.Panel rightPanel;
        private System.Windows.Forms.Button buttonRemoveFileFromList;
        private System.Windows.Forms.Button buttonAddFileToList;
        private System.Windows.Forms.Label labelFileList;
        private System.Windows.Forms.ListBox listBoxFileList;
        private System.Windows.Forms.Button buttonSaveAsProject;
        private System.Windows.Forms.Label labelAdditionalParams;
        private System.Windows.Forms.TextBox textBoxAdditionalParams;
        private System.Windows.Forms.CheckBox checkBoxUsingAdditionalParams;
        private System.Windows.Forms.TextBox textBoxTopModuleName;
        private System.Windows.Forms.Label labelTopModule;
        private System.Windows.Forms.Label labelEndProjectPanel;
        private System.Windows.Forms.CheckBox checkBoxUsingTopModule;
        private System.Windows.Forms.Label labelProjectPath;
        private System.Windows.Forms.Button buttonRunJustThis;
        private System.Windows.Forms.Button buttonNewProject;
        private System.Windows.Forms.Button buttonOpenProject;
        private System.Windows.Forms.Label labelDumpFileName;
        private System.Windows.Forms.TextBox textBoxDumpFileName;
        private System.Windows.Forms.CheckBox checkBoxHaveDump;
        private System.Windows.Forms.TextBox textBoxOutputFileName;
        private System.Windows.Forms.Label labelOutputFileName;
        private System.Windows.Forms.TextBox textBoxProjectFile;
        private System.Windows.Forms.Label labelProjectHeader;
        private System.Windows.Forms.RichTextBox consoleRichTextBox;
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.SplitContainer splitContainerConsole;
        private System.Windows.Forms.Button buttonConsoleClear;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelProjectType;
        private System.Windows.Forms.Panel panelNewProjectType;
        private System.Windows.Forms.Button buttonNewProjectVerilog;
        private System.Windows.Forms.Button buttonNewProjectVHDL;
        private System.Windows.Forms.Panel panelVerilogProject;
    }
}

