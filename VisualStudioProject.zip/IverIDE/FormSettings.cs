﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace IverIDE
{
    public partial class FormSettings : Form
    {
        public FormSettings()
        {
            InitializeComponent();
        }

  
        
        // Buttons open settings panels ----------------------------------------------

        private void CloseAllPanels()
        {
            for (int i = 0; i < panelSettingsWindow.Controls.Count; i++)
            {
                panelSettingsWindow.Controls[i].Enabled = false;
                panelSettingsWindow.Controls[i].Visible = false;
            }
        }


        private void buttonSetMainSett_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            groupBoxMainSett.Enabled = true;
            groupBoxMainSett.Visible = true;
        }

        private void buttonSetFileAssoc_Click(object sender, EventArgs e)
        {
            CloseAllPanels();
            groupBoxFileAssoc.Enabled = true;
            groupBoxFileAssoc.Visible = true;
        }




        // File assotiating --------------------------------------------------------


        private void buttonSetFileAssocAssociateFiles_Click(object sender, EventArgs e)
        {
            Program.Associate();
        }

    }
}
