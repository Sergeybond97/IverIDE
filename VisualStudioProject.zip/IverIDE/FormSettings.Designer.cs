﻿namespace IverIDE
{
    partial class FormSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSettings));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panelSettingsMenu = new System.Windows.Forms.Panel();
            this.panelSettingsWindow = new System.Windows.Forms.Panel();
            this.groupBoxFileAssoc = new System.Windows.Forms.GroupBox();
            this.buttonSetMainSett = new System.Windows.Forms.Button();
            this.groupBoxMainSett = new System.Windows.Forms.GroupBox();
            this.buttonSetFileAssoc = new System.Windows.Forms.Button();
            this.buttonSetFileAssocAssociateFiles = new System.Windows.Forms.Button();
            this.labelSetFileAssoc1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.panelSettingsMenu.SuspendLayout();
            this.panelSettingsWindow.SuspendLayout();
            this.groupBoxFileAssoc.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panelSettingsMenu, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panelSettingsWindow, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(800, 450);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panelSettingsMenu
            // 
            this.panelSettingsMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panelSettingsMenu.Controls.Add(this.buttonSetFileAssoc);
            this.panelSettingsMenu.Controls.Add(this.buttonSetMainSett);
            this.panelSettingsMenu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSettingsMenu.Location = new System.Drawing.Point(3, 3);
            this.panelSettingsMenu.Name = "panelSettingsMenu";
            this.panelSettingsMenu.Size = new System.Drawing.Size(194, 444);
            this.panelSettingsMenu.TabIndex = 0;
            // 
            // panelSettingsWindow
            // 
            this.panelSettingsWindow.Controls.Add(this.groupBoxFileAssoc);
            this.panelSettingsWindow.Controls.Add(this.groupBoxMainSett);
            this.panelSettingsWindow.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelSettingsWindow.Location = new System.Drawing.Point(203, 3);
            this.panelSettingsWindow.Name = "panelSettingsWindow";
            this.panelSettingsWindow.Size = new System.Drawing.Size(594, 444);
            this.panelSettingsWindow.TabIndex = 1;
            // 
            // groupBoxFileAssoc
            // 
            this.groupBoxFileAssoc.Controls.Add(this.labelSetFileAssoc1);
            this.groupBoxFileAssoc.Controls.Add(this.buttonSetFileAssocAssociateFiles);
            this.groupBoxFileAssoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxFileAssoc.Enabled = false;
            this.groupBoxFileAssoc.Location = new System.Drawing.Point(0, 0);
            this.groupBoxFileAssoc.Name = "groupBoxFileAssoc";
            this.groupBoxFileAssoc.Size = new System.Drawing.Size(594, 444);
            this.groupBoxFileAssoc.TabIndex = 0;
            this.groupBoxFileAssoc.TabStop = false;
            this.groupBoxFileAssoc.Text = "Files associating";
            this.groupBoxFileAssoc.Visible = false;
            // 
            // buttonSetMainSett
            // 
            this.buttonSetMainSett.Location = new System.Drawing.Point(7, 7);
            this.buttonSetMainSett.Name = "buttonSetMainSett";
            this.buttonSetMainSett.Size = new System.Drawing.Size(175, 25);
            this.buttonSetMainSett.TabIndex = 0;
            this.buttonSetMainSett.Text = "Main settings";
            this.buttonSetMainSett.UseVisualStyleBackColor = true;
            this.buttonSetMainSett.Click += new System.EventHandler(this.buttonSetMainSett_Click);
            // 
            // groupBoxMainSett
            // 
            this.groupBoxMainSett.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBoxMainSett.Enabled = false;
            this.groupBoxMainSett.Location = new System.Drawing.Point(0, 0);
            this.groupBoxMainSett.Name = "groupBoxMainSett";
            this.groupBoxMainSett.Size = new System.Drawing.Size(594, 444);
            this.groupBoxMainSett.TabIndex = 1;
            this.groupBoxMainSett.TabStop = false;
            this.groupBoxMainSett.Text = "Main settings";
            this.groupBoxMainSett.Visible = false;
            // 
            // buttonSetFileAssoc
            // 
            this.buttonSetFileAssoc.Location = new System.Drawing.Point(7, 38);
            this.buttonSetFileAssoc.Name = "buttonSetFileAssoc";
            this.buttonSetFileAssoc.Size = new System.Drawing.Size(175, 25);
            this.buttonSetFileAssoc.TabIndex = 1;
            this.buttonSetFileAssoc.Text = "File association";
            this.buttonSetFileAssoc.UseVisualStyleBackColor = true;
            this.buttonSetFileAssoc.Click += new System.EventHandler(this.buttonSetFileAssoc_Click);
            // 
            // buttonSetFileAssocAssociateFiles
            // 
            this.buttonSetFileAssocAssociateFiles.Location = new System.Drawing.Point(29, 88);
            this.buttonSetFileAssocAssociateFiles.Name = "buttonSetFileAssocAssociateFiles";
            this.buttonSetFileAssocAssociateFiles.Size = new System.Drawing.Size(152, 36);
            this.buttonSetFileAssocAssociateFiles.TabIndex = 0;
            this.buttonSetFileAssocAssociateFiles.Text = "Associate files";
            this.buttonSetFileAssocAssociateFiles.UseVisualStyleBackColor = true;
            this.buttonSetFileAssocAssociateFiles.Click += new System.EventHandler(this.buttonSetFileAssocAssociateFiles_Click);
            // 
            // labelSetFileAssoc1
            // 
            this.labelSetFileAssoc1.AutoSize = true;
            this.labelSetFileAssoc1.Location = new System.Drawing.Point(26, 61);
            this.labelSetFileAssoc1.Name = "labelSetFileAssoc1";
            this.labelSetFileAssoc1.Size = new System.Drawing.Size(186, 13);
            this.labelSetFileAssoc1.TabIndex = 1;
            this.labelSetFileAssoc1.Text = "Associate files   .v  .vpr    with IverIDE";
            // 
            // FormSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormSettings";
            this.ShowIcon = false;
            this.Text = "Program settings";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panelSettingsMenu.ResumeLayout(false);
            this.panelSettingsWindow.ResumeLayout(false);
            this.groupBoxFileAssoc.ResumeLayout(false);
            this.groupBoxFileAssoc.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panelSettingsMenu;
        private System.Windows.Forms.Button buttonSetFileAssoc;
        private System.Windows.Forms.Button buttonSetMainSett;
        private System.Windows.Forms.Panel panelSettingsWindow;
        private System.Windows.Forms.GroupBox groupBoxMainSett;
        private System.Windows.Forms.GroupBox groupBoxFileAssoc;
        private System.Windows.Forms.Label labelSetFileAssoc1;
        private System.Windows.Forms.Button buttonSetFileAssocAssociateFiles;
    }
}