﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
//using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.IO;
using System.CodeDom.Compiler;
using Microsoft.CSharp;
using System.Reflection;
using System.Text.RegularExpressions;



namespace IverIDE
{
    public partial class Form1 : Form
    {


        ScintillaNET_FindReplaceDialog.FindReplace findReplaceDialog; // FindReplace object instance

        // Variables ------------------------------------------------------------------

        string progectFileVersion = "0.1.8";

        string startupPath = Application.StartupPath; // Получаем путь до папки с программой

        string iverilogPath = @"\iverilog";

        string ghdlPath = @"\ghdl";

        string gtkwavePath = @"\gtkwave";

        //IniSettings INI = new IniSettings(new FileInfo("config.ini").FullName.ToString());         // Файл настроек

        private int untitledTabsCount = 0;

        private List<TabData> tabsData = new List<TabData>();         // Данные вкладок
        private List<ModuleData> moduleData = new List<ModuleData>(); // Данные о модулях в проекте

        // Project file
        string projectStringFromFile = "";

        // Project parameters

        string version = "";
        string projectFile = "";
        string projectType = "";
        string outputFileName = "";
        bool usingDumpFile = false;
        string dumpFileName = "";
        bool usingTopModule = false;
        string topModuleName = "";
        bool usingAdditionalParams = false;
        string additionalParams = "";





        // Initialisation ------------------------------------------------------------------

        public Form1(string file)
        {
            InitializeComponent();
            ConsoleOut("- - - - -  Console  - - - - -");



            if (file.EndsWith(".vpr"))
            {
                OpenProjectOnStart(file);
            }
            else
            {
                OpenFileOnStart(file);
            }
        }

        public Form1()
        {
            InitializeComponent();

            ConsoleOut("- - - - -  Console  - - - - -");

            // New tab
            CreateNewUntitledTab();

            // Initialize project tree
            ClearModuleData();
        }




        public void ConsoleOut(string str)
        {
            consoleRichTextBox.AppendText(str + "\r\n");
            consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length - str.Length - 1;
            consoleRichTextBox.SelectionLength = str.Length + 1;
            consoleRichTextBox.SelectionColor = Color.Black;
            consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length;
            consoleRichTextBox.ScrollToCaret();
        }
        public void ConsoleOut(string str, string type)
        {
            switch (type)
            {
                case "Normal":
                    consoleRichTextBox.AppendText(str + "\r\n");
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length - str.Length - 1;
                    consoleRichTextBox.SelectionLength = str.Length + 1;
                    consoleRichTextBox.SelectionColor = Color.Black;
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length;
                    consoleRichTextBox.ScrollToCaret();
                    break;
                case "Warning":
                    consoleRichTextBox.AppendText(str + "\r\n");
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length - str.Length - 1;
                    consoleRichTextBox.SelectionLength = str.Length + 1;
                    consoleRichTextBox.SelectionColor = Color.Orange;
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length;
                    consoleRichTextBox.ScrollToCaret();
                    break;
                case "Error":
                    consoleRichTextBox.AppendText(str + "\r\n");
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length - str.Length - 1;
                    consoleRichTextBox.SelectionLength = str.Length + 1;
                    consoleRichTextBox.SelectionColor = Color.Red;
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length;
                    consoleRichTextBox.ScrollToCaret();
                    break;
                case "Good":
                    consoleRichTextBox.AppendText(str + "\r\n");
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length - str.Length - 1;
                    consoleRichTextBox.SelectionLength = str.Length + 1;
                    consoleRichTextBox.SelectionColor = Color.Green;
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length;
                    consoleRichTextBox.ScrollToCaret();
                    break;
                case "Command":
                    consoleRichTextBox.AppendText(str + "\r\n");
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length - str.Length - 1;
                    consoleRichTextBox.SelectionLength = str.Length + 1;
                    consoleRichTextBox.SelectionColor = Color.Blue;
                    consoleRichTextBox.SelectionStart = consoleRichTextBox.Text.Length;
                    consoleRichTextBox.ScrollToCaret();
                    break;
            }

        }


        // Program functions ------------------------------------------------------------------

        private void buttonConsoleClear_Click(object sender, EventArgs e)
        {
            consoleRichTextBox.Clear();
        }


        private void ReadSettingsOnStart()
        {
            //if (INI.KeyExists("Height", "SettingForm1"))
            //    //numericUpDown2.Value = int.Parse(INI.Read("SettingForm1", "Height"));
            //else
            //    //numericUpDown2.Value = this.MinimumSize.Height;

            //if (INI.KeyExists("Width", "SettingForm1"))
            //    //numericUpDown1.Value = int.Parse(INI.Read("SettingForm1", "Width"));
            //else
            //    //numericUpDown1.Value = this.MinimumSize.Width;


            ////this.Height = int.Parse(numericUpDown2.Value.ToString());
            ////this.Width = int.Parse(numericUpDown1.Value.ToString());
        }



        private void CreateNewUntitledTab()
        {
            CountUntitledTabs();
            untitledTabsCount++;

            TabPage page = new TabPage();
            page.Text = "Untitled " + untitledTabsCount;

            tabControl.TabPages.Add(page);
            page.Controls.Add(CreateScintillaTextBox());

            TabData tabData = new TabData();
            tabData.documentChanged = false;
            tabData.tabName = page.Text;
            tabData.tabFilePath = "NotSaved";
            tabsData.Add(tabData);

            tabControl.SelectedTab = tabControl.TabPages[tabControl.TabCount - 1];

            // Tie in Scintilla event
            GetScintillaTextBox().KeyDown += scintilla_KeyDown;

            OnTabChangeUpdateUI();
        }

        private void CountUntitledTabs()
        {
            untitledTabsCount = 0;

            if (tabControl.TabPages.Count != 0)
            {
                for (int i = 0; i < tabControl.TabPages.Count; i++) {
                    if (tabsData[i].tabFilePath == "NotSaved")
                    {
                        untitledTabsCount++;
                    }
                }
            }

        }



        private ScintillaNET.Scintilla CreateScintillaTextBox() // Create text box (Scintilla type)
        {
            ScintillaNET.Scintilla textBox = new ScintillaNET.Scintilla();
            textBox.Dock = DockStyle.Fill;
            textBox.Font = new Font("Consolas", 10, textBox.Font.Style);
            textBox.ReadOnly = false;

            textBox.Margins[0].Width = 32;
            textBox.Margins[1].Width = 0;


            // Set the lexer
            textBox.Lexer = ScintillaNET.Lexer.Verilog;

            // Instruct the lexer to calculate folding
            textBox.SetProperty("fold", "1");
            textBox.SetProperty("fold.compact", "1");

            // Configure a margin to display folding symbols
            textBox.Margins[2].Type = ScintillaNET.MarginType.Symbol;
            textBox.Margins[2].Mask = ScintillaNET.Marker.MaskFolders;
            textBox.Margins[2].Sensitive = true;
            textBox.Margins[2].Width = 20;

            // Set colors for all folding markers
            for (int i = 25; i <= 31; i++)
            {
                textBox.Markers[i].SetForeColor(SystemColors.ControlLightLight);
                textBox.Markers[i].SetBackColor(SystemColors.ControlDark);
            }

            // Configure folding markers with respective symbols
            textBox.Markers[ScintillaNET.Marker.Folder].Symbol = ScintillaNET.MarkerSymbol.BoxPlus;
            textBox.Markers[ScintillaNET.Marker.FolderOpen].Symbol = ScintillaNET.MarkerSymbol.BoxMinus;
            textBox.Markers[ScintillaNET.Marker.FolderEnd].Symbol = ScintillaNET.MarkerSymbol.BoxPlusConnected;
            textBox.Markers[ScintillaNET.Marker.FolderMidTail].Symbol = ScintillaNET.MarkerSymbol.TCorner;
            textBox.Markers[ScintillaNET.Marker.FolderOpenMid].Symbol = ScintillaNET.MarkerSymbol.BoxMinusConnected;
            textBox.Markers[ScintillaNET.Marker.FolderSub].Symbol = ScintillaNET.MarkerSymbol.VLine;
            textBox.Markers[ScintillaNET.Marker.FolderTail].Symbol = ScintillaNET.MarkerSymbol.LCorner;

            // Enable automatic folding
            textBox.AutomaticFold = (ScintillaNET.AutomaticFold.Show | ScintillaNET.AutomaticFold.Click | ScintillaNET.AutomaticFold.Change);


            // Configuring the default style with properties
            // we have common to every lexer style saves time.
            textBox.StyleResetDefault();
            textBox.Styles[ScintillaNET.Style.Default].Font = "Consolas";
            textBox.Styles[ScintillaNET.Style.Default].Size = 10;
            textBox.StyleClearAll();


            SelectStyleVerilog(textBox);


            return textBox;
        }

        private void SelectStyleVerilog(ScintillaNET.Scintilla textBox)
        {
            // Configure the Verilog lexer styles
            textBox.Styles[ScintillaNET.Style.Verilog.Default].ForeColor = Color.Silver;
            textBox.Styles[ScintillaNET.Style.Verilog.Comment].ForeColor = Color.FromArgb(0, 128, 0); // Green
            textBox.Styles[ScintillaNET.Style.Verilog.CommentLine].ForeColor = Color.FromArgb(0, 128, 0); // Green
            textBox.Styles[ScintillaNET.Style.Verilog.Number].ForeColor = Color.Olive;
            textBox.Styles[ScintillaNET.Style.Verilog.Word].ForeColor = Color.Blue;
            textBox.Styles[ScintillaNET.Style.Verilog.Word2].ForeColor = Color.BlueViolet;
            // textBox.Styles[ScintillaNET.Style.Verilog.Word3].ForeColor = Color.BlueViolet;
            textBox.Styles[ScintillaNET.Style.Verilog.String].ForeColor = Color.FromArgb(163, 21, 21); // Red
            textBox.Styles[ScintillaNET.Style.Verilog.StringEol].BackColor = Color.Pink;
            textBox.Styles[ScintillaNET.Style.Verilog.Operator].ForeColor = Color.Purple;
            textBox.Styles[ScintillaNET.Style.Verilog.Preprocessor].ForeColor = Color.Brown;
            // textBox.Styles[ScintillaNET.Style.Verilog.Identifier].ForeColor = Color.DarkOrange;
            textBox.Styles[ScintillaNET.Style.Verilog.InOut].ForeColor = Color.Ivory;
            textBox.Styles[ScintillaNET.Style.Verilog.Input].ForeColor = Color.LightCyan;
            textBox.Styles[ScintillaNET.Style.Verilog.Output].ForeColor = Color.Pink;
            textBox.Styles[ScintillaNET.Style.Verilog.PortConnect].ForeColor = Color.Maroon;

            // Set the keywords
            textBox.SetKeywords(0, "module function primitive always assign automatic begin case casex casez cell config deassign default defparam design disable edge else end endcase endconfig endfunction endgenerate endmodule endprimitive endspecify endtable endtask event for force forever fork generate genvar if ifnone incdir include initial instance join liblist library localparam macromodule negedge noshowcancelled parameter posedge primitive pulsestyle_ondetect pulsestyle_onevent release repeat scalared showcancelled specify specparam strength table task triand use vectored wait while");
            textBox.SetKeywords(1, "input output inout reg signed tri tri1 tri0 trireg unsigned wire");
        }

        private void SelectStyleVHDL(ScintillaNET.Scintilla textBox)
        {
            // Configure the VHDL lexer styles
            textBox.Styles[ScintillaNET.Style.Verilog.Default].ForeColor = Color.Silver;
            textBox.Styles[ScintillaNET.Style.Verilog.Comment].ForeColor = Color.FromArgb(0, 128, 0); // Green
            textBox.Styles[ScintillaNET.Style.Verilog.CommentLine].ForeColor = Color.FromArgb(0, 128, 0); // Green
            textBox.Styles[ScintillaNET.Style.Verilog.Number].ForeColor = Color.Olive;
            textBox.Styles[ScintillaNET.Style.Verilog.Word].ForeColor = Color.Blue;
            textBox.Styles[ScintillaNET.Style.Verilog.Word2].ForeColor = Color.BlueViolet;
            // textBox.Styles[ScintillaNET.Style.Verilog.Word3].ForeColor = Color.BlueViolet;
            textBox.Styles[ScintillaNET.Style.Verilog.String].ForeColor = Color.FromArgb(163, 21, 21); // Red
            textBox.Styles[ScintillaNET.Style.Verilog.StringEol].BackColor = Color.Pink;
            textBox.Styles[ScintillaNET.Style.Verilog.Operator].ForeColor = Color.Purple;
            textBox.Styles[ScintillaNET.Style.Verilog.Preprocessor].ForeColor = Color.Brown;
            // textBox.Styles[ScintillaNET.Style.Verilog.Identifier].ForeColor = Color.DarkOrange;
            textBox.Styles[ScintillaNET.Style.Verilog.InOut].ForeColor = Color.Ivory;
            textBox.Styles[ScintillaNET.Style.Verilog.Input].ForeColor = Color.LightCyan;
            textBox.Styles[ScintillaNET.Style.Verilog.Output].ForeColor = Color.Pink;
            textBox.Styles[ScintillaNET.Style.Verilog.PortConnect].ForeColor = Color.Maroon;

            // Set the keywords
            textBox.SetKeywords(0, "abs access after alias all and architecture array assert attribute begin block body buffer bus case component configuration constant disconnect downto else elsif end entity exit file for function generate generic group guarded if impure in inertial inout is label library linkage literal loop map mod nand new next nor not null of on open or others out package port postponed procedure process pure range record register reject rem report return rol ror select severity signal shared sla sll sra srl subtype then to transport type unaffected units until use variable wait when while with xnor xor");
            //textBox.SetKeywords(1, "input output inout reg signed tri tri1 tri0 trireg unsigned wire");
        }

        public ScintillaNET.Scintilla GetScintillaTextBox() // Get text box (Scintilla type)
        {
            ScintillaNET.Scintilla textBox = null;
            TabPage tab = tabControl.SelectedTab;

            if (tab != null)
            {
                textBox = tab.Controls[0] as ScintillaNET.Scintilla;
            }

            return textBox;
        } // Get current tab text


        public string GetCurrentProjectPath()// Project path (w/o file name)
        {
            return System.IO.Path.GetDirectoryName(tabsData[tabControl.SelectedIndex].tabFilePath);
        }

        public string GetCurrentProjectName() // File name
        {
            return tabsData[tabControl.SelectedIndex].tabName;
        }



        public string SpaceCorrection(string path) // For arguments in process start
        {
            return !string.IsNullOrEmpty(path) ?
                path.Contains(" ") ? "\"" + path + "\"" : path
                : string.Empty;
        }



        // File save/load functions -----------------------------------------------------------------------

        private void ScriptFile_Save(string file) // Save file (string from current textbox) (argument file is file path w name)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(file))
                {
                    sw.Write(GetScintillaTextBox().Text);
                }
            }
            catch (Exception e)
            {
                ConsoleOut("Error: Can't write " + file + e.Message, "Error");
            }

        }

        private void ScriptFile_Save(string file, string text) // Save string to file
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(file))
                {
                    sw.Write(text);
                }
            }
            catch (Exception e)
            {
                ConsoleOut("Error: Can't write " + file + e.Message, "Error");
            }
        }

        private void ScriptFile_Load(string file)
        {
            string scriptFile = ""; // All text

            try
            {
                using (StreamReader sr = new StreamReader(file))
                {
                    scriptFile = sr.ReadToEnd();
                }
            }
            catch (Exception e)
            {
                ConsoleOut("Error: Can't open " + file + e.Message, "Error");
            }


            GetScintillaTextBox().Text = scriptFile;
        }


        private void ProjectFile_Save(string file) // Save file (argument file is file path w name)
        {

            try
            {
                using (StreamWriter sw = new StreamWriter(file))
                {
                    sw.Write(projectStringFromFile);
                }
            }
            catch (Exception e)
            {
                ConsoleOut("Error: Can't write " + file + e.Message, "Error");
            }

        }

        private void ProjectFile_Load(string file)
        {

            try
            {
                using (StreamReader sr = new StreamReader(file))
                {
                    projectStringFromFile = sr.ReadToEnd();
                }
            }
            catch (Exception e)
            {
                ConsoleOut("Error: Can't open " + file + e.Message, "Error");
            }

        }






        // Update functions -----------------------------------------------------------------------

        private void OnTabChangeUpdateUI()
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {

            }
        }



        // Processes for icarus compiler -----------------------------------------------------------------------

        public bool StartIcarusCompilator(string inputParam)
        {
            bool processDone = false;
            Process process = new Process(); // Create process

            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.RedirectStandardInput = true; // Is a MUST!
            process.StartInfo.CreateNoWindow = true;
            process.EnableRaisingEvents = true;


            process.StartInfo.FileName = startupPath + iverilogPath + @"\bin\iverilog.exe"; // Program to run
            process.StartInfo.Arguments = inputParam; // Arguments

            //ConsoleOut("Arguments : " + inputParam); // For debug

            process.Exited += (sender, e) => // End process event
            {
                //ConsoleOut("> Compile process done.");
                processDone = true;
            };


            process.Start(); // Start process

            StreamReader srOut = process.StandardOutput; // Take information from process
            StreamReader srErr = process.StandardError;

            string outp = srOut.ReadToEnd();
            string err = srErr.ReadToEnd();

            process.WaitForExit(5000);



            if (outp != "") // Output information from process
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - -  IVerilog output - - - - - - - - - - - - - - - - - - - - - - - -\n" + outp);
            }
            if (err != "")
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - - IVerilog error - - - - - - - - - - - - - - - - - - - - - - - -\n" + err, "Error");
            }
            if (outp == "" && err == "")
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - - IVerilog output - - - - - - - - - - - - - - - - - - - - - - - -\n" + "Compile OK");
            }

            if (processDone) return true;
            else return false;
        }

        public bool StartVVP(string inputParam)
        {
            bool processDone = false;
            Process process = new Process();

            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.RedirectStandardInput = true; // Is a MUST!
            process.StartInfo.CreateNoWindow = true;
            process.EnableRaisingEvents = true;

            process.StartInfo.FileName = startupPath + iverilogPath + @"\bin\vvp.exe";
            process.StartInfo.Arguments = inputParam;

            process.Exited += (sender, e) =>
            {
                //ConsoleOut("> VVP runtime process done.");
                processDone = true;
            };


            process.Start();

            StreamReader srOut = process.StandardOutput;
            StreamReader srErr = process.StandardError;

            string outp = srOut.ReadToEnd();
            string err = srErr.ReadToEnd();

            process.WaitForExit(5000);

            if (outp != "")
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - - VVP runtime output - - - - - - - - - - - - - - - - - - - - - - - -\n" + outp);
            }
            if (err != "")
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - - VVP runtime error - - - - - - - - - - - - - - - - - - - - - - - -\n" + err, "Error");
            }

            if (processDone) return true;
            else return false;
        }

        public void StartGTKWave(string inputParam)
        {
            ConsoleOut("> Starting GTKWave ...", "Command");

            Process process = new Process();
            process.StartInfo.FileName = startupPath + gtkwavePath + @"\bin\gtkwave.exe";
            process.StartInfo.Arguments = inputParam;
            process.StartInfo.CreateNoWindow = true;


            process.Start();
        }


        // Processes for GHDL compiler --------------------------------------------------------------------

        public bool StartGHDLAnalyse(string inputParam)
        {
            bool processDone = false;
            Process process = new Process(); // Create process

            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.RedirectStandardInput = true; // Is a MUST!
            process.StartInfo.CreateNoWindow = true;
            process.EnableRaisingEvents = true;


            process.StartInfo.FileName = startupPath + ghdlPath + @"\bin\ghdl.exe"; // Program to run
            process.StartInfo.Arguments = inputParam; // Arguments

            //ConsoleOut("Arguments : " + inputParam); // For debug

            process.Exited += (sender, e) => // End process event
            {
                //ConsoleOut("> Compile process done.");
                processDone = true;
            };


            process.Start(); // Start process

            StreamReader srOut = process.StandardOutput; // Take information from process
            StreamReader srErr = process.StandardError;

            string outp = srOut.ReadToEnd();
            string err = srErr.ReadToEnd();

            process.WaitForExit(5000);



            if (outp != "") // Output information from process
            {
                ConsoleOut(outp);
            }
            if (err != "")
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - - GHDL error - - - - - - - - - - - - - - - - - - - - - - - -\n" + err, "Error");
            }
            if (outp == "" && err == "")
            {
                ConsoleOut("File : " + inputParam.Substring(3, inputParam.Length - 3));
                ConsoleOut("Analyse OK", "Good");
            }

            if (processDone) return true;
            else return false;
        }

        public bool StartGHDLElaborate(string inputParam)
        {
            bool processDone = false;
            Process process = new Process(); // Create process

            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.RedirectStandardInput = true; // Is a MUST!
            process.StartInfo.CreateNoWindow = true;
            process.EnableRaisingEvents = true;


            process.StartInfo.FileName = startupPath + ghdlPath + @"\bin\ghdl.exe"; // Program to run
            process.StartInfo.Arguments = inputParam; // Arguments

            //ConsoleOut("Arguments : " + inputParam); // For debug

            process.Exited += (sender, e) => // End process event
            {
                //ConsoleOut("> Compile process done.");
                processDone = true;
            };


            process.Start(); // Start process

            StreamReader srOut = process.StandardOutput; // Take information from process
            StreamReader srErr = process.StandardError;

            string outp = srOut.ReadToEnd();
            string err = srErr.ReadToEnd();

            process.WaitForExit(5000);



            if (outp != "") // Output information from process
            {
                ConsoleOut(outp);
            }
            if (err != "")
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - - GHDL error - - - - - - - - - - - - - - - - - - - - - - - -\n" + err, "Error");
            }
            if (outp == "" && err == "")
            {
                ConsoleOut("Entity : " + inputParam.Substring(3, inputParam.Length - 3));
                ConsoleOut("Elaborate OK", "Good");
            }

            if (processDone) return true;
            else return false;
        }

        public bool StartGHDLRun(string inputParam)
        {
            bool processDone = false;
            Process process = new Process(); // Create process

            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardOutput = true;
            process.StartInfo.RedirectStandardError = true;
            process.StartInfo.RedirectStandardInput = true; // Is a MUST!
            process.StartInfo.CreateNoWindow = true;
            process.EnableRaisingEvents = true;


            process.StartInfo.FileName = startupPath + ghdlPath + @"\bin\ghdl.exe"; // Program to run
            process.StartInfo.Arguments = inputParam; // Arguments

            //ConsoleOut("Arguments : " + inputParam); // For debug

            process.Exited += (sender, e) => // End process event
            {
                //ConsoleOut("> Compile process done.");
                processDone = true;
            };


            process.Start(); // Start process

            StreamReader srOut = process.StandardOutput; // Take information from process
            StreamReader srErr = process.StandardError;

            string outp = srOut.ReadToEnd();
            string err = srErr.ReadToEnd();

            process.WaitForExit(5000);



            if (outp != "") // Output information from process
            {
                ConsoleOut(outp);
            }
            if (err != "")
            {
                ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - - GHDL error - - - - - - - - - - - - - - - - - - - - - - - -\n" + err, "Error");
            }
            if (outp == "" && err == "")
            {
                ConsoleOut("File : " + inputParam.Substring(3, inputParam.Length - 3));
                ConsoleOut("Run OK", "Good");
            }

            if (processDone) return true;
            else return false;
        }

        // File functions to buttons -----------------------------------------------------------------------

        private void UIFileNew() // New file
        {
            int selectedTabIndex = tabControl.SelectedIndex;


            if (selectedTabIndex != -1)
            {
                if (tabsData[selectedTabIndex].documentChanged)
                {

                }
                else
                {
                    CreateNewUntitledTab();
                }
            }
            else
            {
                CreateNewUntitledTab();
            }



        }

        private void UIFileOpen() // Open file
        {
            openFileDialog.Filter = "Verilog file(*.v)|*.v|VHDL file(*.vhdl)|*.vhdl|All files(*.*)|*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                for (int i = 0; i < tabsData.Count; i++)
                    if (tabsData[i].tabFilePath == openFileDialog.FileName)
                    {
                        tabControl.SelectedTab = tabControl.TabPages[i];
                        return;
                    }
                TabPage page = new TabPage();
                page.Text = System.IO.Path.GetFileName(openFileDialog.FileName);

                tabControl.TabPages.Add(page);
                page.Controls.Add(CreateScintillaTextBox());

                TabData tabData = new TabData();
                tabData.documentChanged = false;
                tabData.tabName = System.IO.Path.GetFileName(openFileDialog.FileName);
                tabData.tabFilePath = openFileDialog.FileName;
                tabsData.Add(tabData);

                tabControl.SelectedTab = tabControl.TabPages[tabControl.TabCount - 1];

                ScriptFile_Load(openFileDialog.FileName);
                //GetRichTextBox().LoadFile(openPrgFileDialog.FileName, RichTextBoxStreamType.PlainText);

                // Tie in Scintilla event
                GetScintillaTextBox().KeyDown += scintilla_KeyDown;

                if (System.IO.Path.GetExtension(openFileDialog.FileName) == ".v")
                {
                    SelectStyleVerilog(GetScintillaTextBox());
                }
                else if (System.IO.Path.GetExtension(openFileDialog.FileName) == ".vhdl")
                {
                    SelectStyleVHDL(GetScintillaTextBox());
                }

                ConsoleOut("> Opened : " + tabData.tabFilePath, "Command");
            }
        }

        private void UIFileSaveAs() // Save file as
        {
            saveFileDialog.Filter = "Verilog file(*.v) |*.v| All files(*.*) | *.*";

            int selectedTabIndex = tabControl.SelectedIndex;

            if (saveFileDialog.ShowDialog() == DialogResult.OK &&
            saveFileDialog.FileName.Length > 0)
            {

                tabsData[selectedTabIndex].documentChanged = false;
                tabsData[selectedTabIndex].tabName = System.IO.Path.GetFileName(saveFileDialog.FileName);
                tabsData[selectedTabIndex].tabFilePath = saveFileDialog.FileName;

                ScriptFile_Save(saveFileDialog.FileName);

                tabControl.SelectedTab.Text = System.IO.Path.GetFileName(saveFileDialog.FileName);

                ConsoleOut("> Saved as : " + tabsData[selectedTabIndex].tabFilePath, "Command");
            }


        }

        private void UIFileSave() // Save file
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (tabsData[selectedTabIndex].tabFilePath == "NotSaved")
            {
                UIFileSaveAs();
            }
            else
            {
                tabsData[selectedTabIndex].documentChanged = false;

                ScriptFile_Save(tabsData[selectedTabIndex].tabFilePath);

                ConsoleOut("> Saved : " + tabsData[selectedTabIndex].tabFilePath, "Command");

            }


        }


        // File functions on program start 

        private void OpenFileOnStart(string file)
        {
            for (int i = 0; i < tabsData.Count; i++)
                if (tabsData[i].tabFilePath == file)
                {
                    tabControl.SelectedTab = tabControl.TabPages[i];
                    return;
                }
            TabPage page = new TabPage();
            page.Text = System.IO.Path.GetFileName(file);

            tabControl.TabPages.Add(page);
            page.Controls.Add(CreateScintillaTextBox());

            TabData tabData = new TabData();
            tabData.documentChanged = false;
            tabData.tabName = System.IO.Path.GetFileName(file);
            tabData.tabFilePath = file;
            tabsData.Add(tabData);

            tabControl.SelectedTab = tabControl.TabPages[tabControl.TabCount - 1];

            ScriptFile_Load(file);

            // Tie in Scintilla event
            GetScintillaTextBox().KeyDown += scintilla_KeyDown;

            ConsoleOut("> Opened : " + tabData.tabFilePath, "Command");
        }

        private void OpenProjectOnStart(string file)
        {
            ProjectFile_Load(file);

            if (projectStringFromFile != "")
            {
                if (UIOpenProject_RecieveVersion() && UIOpenProject_RecieveType() && UIOpenProject_RecieveOutputFile() && UIOpenProject_RecieveFileList()) // Project file OK // All NECESSARY vars loaded
                {
                    projectFile = file;
                    textBoxProjectFile.Text = file;

                    labelProjectHeader.Text = System.IO.Path.GetFileNameWithoutExtension(file);
                    labelProjectType.Text = projectType;

                    textBoxOutputFileName.Text = outputFileName;


                    //Checking additional vars

                    if (UIOpenProject_RecieveTopModule())
                    {
                        checkBoxUsingTopModule.CheckState = CheckState.Checked;
                        textBoxTopModuleName.Text = topModuleName;
                    }
                    else
                    {
                        checkBoxUsingTopModule.CheckState = CheckState.Unchecked;
                    }
                    if (UIOpenProject_RecieveOpenDump())
                    {
                        checkBoxHaveDump.CheckState = CheckState.Checked;
                        textBoxDumpFileName.Text = dumpFileName;
                    }
                    else
                    {
                        checkBoxHaveDump.CheckState = CheckState.Unchecked;
                    }
                    if (UIOpenProject_RecieveAddParams())
                    {
                        checkBoxUsingAdditionalParams.CheckState = CheckState.Checked;
                        textBoxAdditionalParams.Text = additionalParams;
                    }
                    else
                    {
                        checkBoxUsingAdditionalParams.CheckState = CheckState.Unchecked;
                    }



                    ConsoleOut("> Opened project: " + file, "Command");


                    // Enable UI elements ============

                    buttonRunJustThis.Enabled = false;
                    buttonRunJustThis.Visible = false;

                    buttonSaveAsProject.Enabled = true;
                    buttonSaveAsProject.Visible = true;

                    if (projectType == "Verilog")
                    {
                        UIOpenProject_UIElementsVerilog();



                        return;
                    }
                    else if (projectType == "VHDL")
                    {
                        UIOpenProject_UIElementsVHDL();



                        return;
                    }

                }
                else // Project file error
                {
                    ConsoleOut("> Error : Cannot open project file", "Error");
                    return;
                }


            }
            else
            {
                ConsoleOut("> Error : Project file is empty", "Error");
                return;
            }


        }


        // Project functions ------------------------------------------------------------------


        private void UIOpenProject() // Open project
        {

            // Open project
            openFileDialog.Filter = "Iver project file(*.vpr) |*.vpr| All files(*.*) |*.*";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ProjectFile_Load(openFileDialog.FileName);

                if (projectStringFromFile != "")
                {
                    if (UIOpenProject_RecieveVersion() && UIOpenProject_RecieveType() && UIOpenProject_RecieveOutputFile() && UIOpenProject_RecieveFileList()) // Project file OK // All NECESSARY vars loaded
                    {
                        projectFile = openFileDialog.FileName;
                        textBoxProjectFile.Text = openFileDialog.FileName;

                        labelProjectHeader.Text = System.IO.Path.GetFileNameWithoutExtension(openFileDialog.FileName);
                        labelProjectType.Text = projectType;

                        textBoxOutputFileName.Text = outputFileName;


                        //Checking additional vars

                        if (UIOpenProject_RecieveTopModule())
                        {
                            checkBoxUsingTopModule.CheckState = CheckState.Checked;
                            textBoxTopModuleName.Text = topModuleName;
                        }
                        else
                        {
                            checkBoxUsingTopModule.CheckState = CheckState.Unchecked;
                        }
                        if (UIOpenProject_RecieveOpenDump())
                        {
                            checkBoxHaveDump.CheckState = CheckState.Checked;
                            textBoxDumpFileName.Text = dumpFileName;
                        }
                        else
                        {
                            checkBoxHaveDump.CheckState = CheckState.Unchecked;
                        }
                        if (UIOpenProject_RecieveAddParams())
                        {
                            checkBoxUsingAdditionalParams.CheckState = CheckState.Checked;
                            textBoxAdditionalParams.Text = additionalParams;
                        }
                        else
                        {
                            checkBoxUsingAdditionalParams.CheckState = CheckState.Unchecked;
                        }



                        ConsoleOut("> Opened project: " + openFileDialog.FileName, "Command");


                        // Enable UI elements ============

                        buttonRunJustThis.Enabled = false;
                        buttonRunJustThis.Visible = false;

                        buttonSaveAsProject.Enabled = true;
                        buttonSaveAsProject.Visible = true;

                        if (projectType == "Verilog")
                        {
                            UIOpenProject_UIElementsVerilog();



                            return;
                        }
                        else if (projectType == "VHDL")
                        {
                            UIOpenProject_UIElementsVHDL();



                            return;
                        }

                    }
                    else // Project file error
                    {
                        ConsoleOut("> Error : Cannot open project file", "Error");
                        return;
                    }


                }
                else
                {
                    ConsoleOut("> Error : Project file is empty", "Error");
                    return;
                }



            }

        }

        private bool UIOpenProject_RecieveVersion()
        {
            string varToRecieve = "VER=";
            if (projectStringFromFile.Contains(varToRecieve))
            {
                int startInd = projectStringFromFile.IndexOf(varToRecieve, 0) + varToRecieve.Length;
                int endInd = projectStringFromFile.IndexOf("\n", startInd) - 1; // (-1) for return in the end of string
                //ConsoleOut("start " + startInd + " end " + endInd); // Debug
                version = projectStringFromFile.Substring(startInd, endInd - startInd);
                //ConsoleOut("version = " + version); //Debug


                if (version != progectFileVersion)
                {
                    ConsoleOut("> Error : Project file not for this version of program" + "( Project = " + version + " , Program = " + progectFileVersion + " )", "Error");
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                ConsoleOut("> Error : Project file doesn't have " + varToRecieve + " variable", "Error");
                return false;
            }
        }

        private bool UIOpenProject_RecieveType()
        {
            string varToRecieve = "TYPE=";
            if (projectStringFromFile.Contains(varToRecieve))
            {
                int startInd = projectStringFromFile.IndexOf(varToRecieve, 0) + varToRecieve.Length;
                int endInd = projectStringFromFile.IndexOf("\n", startInd) - 1; // (-1) for return in the end of string
                //ConsoleOut("start " + startInd + " end " + endInd); // Debug
                projectType = projectStringFromFile.Substring(startInd, endInd - startInd);
                //ConsoleOut("version = " + version); //Debug


                if (projectType == "Verilog" || projectType == "VHDL")
                {
                    return true;
                }
                else
                {
                    ConsoleOut("> Error : Project type is not Verilog or VHDL", "Error");
                    return false;
                }
            }
            else
            {
                ConsoleOut("> Error : Project file doesn't have " + varToRecieve + " variable", "Error");
                return false;
            }
        }

        private bool UIOpenProject_RecieveOutputFile()
        {
            string varToRecieve = "OUTPUT_FILE=";
            if (projectStringFromFile.Contains(varToRecieve))
            {
                int startInd = projectStringFromFile.IndexOf(varToRecieve, 0) + varToRecieve.Length;
                int endInd = projectStringFromFile.IndexOf("\n", startInd) - 1; // (-1) for return in the end of string
                //ConsoleOut("start " + startInd + " end " + endInd); // Debug
                outputFileName = projectStringFromFile.Substring(startInd, endInd - startInd);
                //ConsoleOut("outputFile = " + outputFileName); //Debug


                if (outputFileName != "")
                {
                    return true;
                }
                else
                {
                    ConsoleOut("> Error : " + varToRecieve + " is empty", "Error");
                    return false;
                }

            }
            else
            {
                ConsoleOut("> Error : Project file doesn't have " + varToRecieve + " variable", "Error");
                return false;
            }
        }

        private bool UIOpenProject_RecieveFileList()
        {
            string varToRecieve = "FILE_LIST";
            string varEndBlock = "END_FILE_LIST";
            if (projectStringFromFile.Contains(varToRecieve) && projectStringFromFile.Contains(varEndBlock))
            {
                int startInd = projectStringFromFile.IndexOf(varToRecieve, 0) + varToRecieve.Length;
                int endInd = projectStringFromFile.IndexOf(varEndBlock, startInd);
                //ConsoleOut("st : " + startInd.ToString() + "end : " + endInd.ToString()); //Debug

                int curInd = startInd + 2; // Нужно узнать почему тут 2-ка получается !!!!!!!!!!

                ClearModuleData();

                while (curInd < endInd)
                {
                    ModuleData newModule = new ModuleData();

                    newModule.moduleName = projectStringFromFile.Substring(curInd, projectStringFromFile.IndexOf("\r", curInd) - curInd);
                    curInd = projectStringFromFile.IndexOf("\r", curInd) + 2;
                    newModule.moduleFilePath = projectStringFromFile.Substring(curInd, projectStringFromFile.IndexOf("\r", curInd) - curInd);
                    curInd = projectStringFromFile.IndexOf("\r", curInd) + 2;

                    AddModule(newModule);
                }

                return true;
            }
            else
            {
                ConsoleOut("> Error : Project file doesn't have " + varToRecieve + " variable", "Error");
                return false;
            }
        }

        private bool UIOpenProject_RecieveTopModule()
        {
            string varToRecieve = "TOP_MODULE=";
            if (projectStringFromFile.Contains(varToRecieve))
            {
                int startInd = projectStringFromFile.IndexOf(varToRecieve, 0) + varToRecieve.Length;
                int endInd = projectStringFromFile.IndexOf("\n", startInd) - 1; // (-1) for return in the end of string
                //ConsoleOut("start " + startInd + " end " + endInd); // Debug
                topModuleName = projectStringFromFile.Substring(startInd, endInd - startInd);
                //ConsoleOut("topModule = " + topModuleName); //Debug


                if (topModuleName != "")
                {
                    usingTopModule = true;
                    return true;
                }
                else
                {
                    usingTopModule = false;
                    return false;
                }

            }
            else
            {
                usingTopModule = false;
                return false;
            }
        }

        private bool UIOpenProject_RecieveOpenDump()
        {
            string varToRecieve = "OPEN_DUMP=";
            if (projectStringFromFile.Contains(varToRecieve))
            {
                int startInd = projectStringFromFile.IndexOf(varToRecieve, 0) + varToRecieve.Length;
                int endInd = projectStringFromFile.IndexOf("\n", startInd) - 1; // (-1) for return in the end of string
                //ConsoleOut("start " + startInd + " end " + endInd); // Debug
                dumpFileName = projectStringFromFile.Substring(startInd, endInd - startInd);
                //ConsoleOut("openDump = " + dumpFileName); //Debug


                if (dumpFileName != "")
                {
                    usingDumpFile = true;
                    return true;
                }
                else
                {
                    usingDumpFile = false;
                    return false;
                }

            }
            else
            {
                usingDumpFile = false;
                return false;
            }
        }

        private bool UIOpenProject_RecieveAddParams()
        {
            string varToRecieve = "ADD_PARAMS=";
            if (projectStringFromFile.Contains(varToRecieve))
            {
                int startInd = projectStringFromFile.IndexOf(varToRecieve, 0) + varToRecieve.Length;
                int endInd = projectStringFromFile.IndexOf("\n", startInd) - 1; // (-1) for return in the end of string
                //ConsoleOut("start " + startInd + " end " + endInd); // Debug
                additionalParams = projectStringFromFile.Substring(startInd, endInd - startInd);
                //ConsoleOut("addParams = " + additionalParams); //Debug


                if (additionalParams != "")
                {
                    usingAdditionalParams = true;
                    return true;
                }
                else
                {
                    usingAdditionalParams = false;
                    return false;
                }

            }
            else
            {
                usingAdditionalParams = false;
                return false;
            }
        }

        private void UIOpenProject_UIElementsVerilog()
        {
            checkBoxUsingTopModule.Visible = true;
            textBoxTopModuleName.Visible = true;
            labelTopModule.Visible = true;


            checkBoxUsingAdditionalParams.Visible = true;
            labelAdditionalParams.Visible = true;
            textBoxAdditionalParams.Visible = true;

            labelOutputFileName.Text = "Output file name";

        }

        private void UIOpenProject_UIElementsVHDL()
        {
            checkBoxUsingTopModule.Visible = false;
            textBoxTopModuleName.Visible = false;
            labelTopModule.Visible = false;


            checkBoxUsingAdditionalParams.Visible = false;
            labelAdditionalParams.Visible = false;
            textBoxAdditionalParams.Visible = false;

            labelOutputFileName.Text = "Elaborate entity";
        }


        private void UINewProject() // New project
        {
            panelNewProjectType.Visible = true;
            panelNewProjectType.Enabled = true;
        }

        private void NewVerilogProject()
        {
            saveFileDialog.Filter = "Iver project file(*.vpr) |*.vpr| All files(*.*) |*.*";


            if (saveFileDialog.ShowDialog() == DialogResult.OK &&
            saveFileDialog.FileName.Length > 0)
            {
                //Create and save new project

                projectStringFromFile = ""; // Clear string to save

                projectFile = saveFileDialog.FileName;
                version = progectFileVersion;
                projectType = "Verilog";
                outputFileName = System.IO.Path.GetFileNameWithoutExtension(saveFileDialog.FileName) + "_output";
                usingDumpFile = false;
                dumpFileName = "";
                usingTopModule = false;
                topModuleName = "";
                usingAdditionalParams = false;
                additionalParams = "";

                moduleData.Clear();
                ClearTree();

                UISaveProject_SaveVersion();
                UISaveProject_SaveProjectType();
                UISaveProject_SaveOutputFile();
                UISaveProject_SaveFileList();
                UISaveProject_SaveOpenDump();
                UISaveProject_SaveTopModule();
                UISaveProject_SaveAddParams();

                ProjectFile_Save(saveFileDialog.FileName);

                ConsoleOut("> Project saved as : " + saveFileDialog.FileName, "Command");

                // Open new project

                ProjectFile_Load(saveFileDialog.FileName);

                if (projectStringFromFile != "")
                {
                    if (UIOpenProject_RecieveVersion() && UIOpenProject_RecieveType() && UIOpenProject_RecieveOutputFile()) // Project file OK // All NECESSARY vars loaded
                    {
                        projectFile = saveFileDialog.FileName;
                        textBoxProjectFile.Text = saveFileDialog.FileName;

                        labelProjectHeader.Text = System.IO.Path.GetFileNameWithoutExtension(saveFileDialog.FileName);
                        labelProjectType.Text = projectType;

                        textBoxOutputFileName.Text = outputFileName;


                        //Checking additional vars

                        if (UIOpenProject_RecieveTopModule())
                        {
                            checkBoxUsingTopModule.CheckState = CheckState.Checked;
                            textBoxTopModuleName.Text = topModuleName;
                        }
                        else
                        {
                            checkBoxUsingTopModule.CheckState = CheckState.Unchecked;
                        }
                        if (UIOpenProject_RecieveOpenDump())
                        {
                            checkBoxHaveDump.CheckState = CheckState.Checked;
                            textBoxDumpFileName.Text = dumpFileName;
                        }
                        else
                        {
                            checkBoxHaveDump.CheckState = CheckState.Unchecked;
                        }
                        if (UIOpenProject_RecieveAddParams())
                        {
                            checkBoxUsingAdditionalParams.CheckState = CheckState.Checked;
                            textBoxAdditionalParams.Text = additionalParams;
                        }
                        else
                        {
                            checkBoxUsingAdditionalParams.CheckState = CheckState.Unchecked;
                        }

                        // Enable UI elements

                        buttonRunJustThis.Enabled = false;
                        buttonRunJustThis.Visible = false;

                        buttonSaveAsProject.Enabled = true;
                        buttonSaveAsProject.Visible = true;

                        UIOpenProject_UIElementsVerilog();




                    }
                    else // Project file error
                    {
                        ConsoleOut("> Error : Cannot open project file", "Error");
                        return;
                    }


                }
                else
                {
                    ConsoleOut("> Error : Project file is empty", "Error");
                    return;
                }
            }

            panelNewProjectType.Visible = false;
            panelNewProjectType.Enabled = false;
        }

        private void NewVHDLProject()
        {
            saveFileDialog.Filter = "Iver project file(*.vpr) |*.vpr| All files(*.*) |*.*";


            if (saveFileDialog.ShowDialog() == DialogResult.OK &&
            saveFileDialog.FileName.Length > 0)
            {
                //Create and save new project

                projectStringFromFile = ""; // Clear string to save

                projectFile = saveFileDialog.FileName;
                version = progectFileVersion;
                projectType = "VHDL";
                outputFileName = System.IO.Path.GetFileNameWithoutExtension(saveFileDialog.FileName) + "_output";
                usingDumpFile = false;
                dumpFileName = "";
                usingTopModule = false;
                topModuleName = "";
                usingAdditionalParams = false;
                additionalParams = "";

                moduleData.Clear();
                ClearTree();

                UISaveProject_SaveVersion();
                UISaveProject_SaveProjectType();
                UISaveProject_SaveOutputFile();
                UISaveProject_SaveFileList();
                UISaveProject_SaveOpenDump();
                UISaveProject_SaveTopModule();
                UISaveProject_SaveAddParams();

                ProjectFile_Save(saveFileDialog.FileName);

                ConsoleOut("> Project saved as : " + saveFileDialog.FileName, "Command");

                // Open new project

                ProjectFile_Load(saveFileDialog.FileName);

                if (projectStringFromFile != "")
                {
                    if (UIOpenProject_RecieveVersion() && UIOpenProject_RecieveType() && UIOpenProject_RecieveOutputFile()) // Project file OK // All NECESSARY vars loaded
                    {
                        projectFile = saveFileDialog.FileName;
                        textBoxProjectFile.Text = saveFileDialog.FileName;

                        labelProjectHeader.Text = System.IO.Path.GetFileNameWithoutExtension(saveFileDialog.FileName);
                        labelProjectType.Text = projectType;

                        textBoxOutputFileName.Text = outputFileName;


                        //Checking additional vars

                        if (UIOpenProject_RecieveTopModule())
                        {
                            checkBoxUsingTopModule.CheckState = CheckState.Checked;
                            textBoxTopModuleName.Text = topModuleName;
                        }
                        else
                        {
                            checkBoxUsingTopModule.CheckState = CheckState.Unchecked;
                        }
                        if (UIOpenProject_RecieveOpenDump())
                        {
                            checkBoxHaveDump.CheckState = CheckState.Checked;
                            textBoxDumpFileName.Text = dumpFileName;
                        }
                        else
                        {
                            checkBoxHaveDump.CheckState = CheckState.Unchecked;
                        }
                        if (UIOpenProject_RecieveAddParams())
                        {
                            checkBoxUsingAdditionalParams.CheckState = CheckState.Checked;
                            textBoxAdditionalParams.Text = additionalParams;
                        }
                        else
                        {
                            checkBoxUsingAdditionalParams.CheckState = CheckState.Unchecked;
                        }

                        // Enable UI elements

                        buttonRunJustThis.Enabled = false;
                        buttonRunJustThis.Visible = false;

                        buttonSaveAsProject.Enabled = true;
                        buttonSaveAsProject.Visible = true;

                        UIOpenProject_UIElementsVHDL();




                    }
                    else // Project file error
                    {
                        ConsoleOut("> Error : Cannot open project file", "Error");
                        return;
                    }


                }
                else
                {
                    ConsoleOut("> Error : Project file is empty", "Error");
                    return;
                }
            }

            panelNewProjectType.Visible = false;
            panelNewProjectType.Enabled = false;
        }



        private void UISaveAsProject() // Save project
        {
            saveFileDialog.Filter = "Iver project file(*.vpr) |*.vpr| All files(*.*) |*.*";


            if (saveFileDialog.ShowDialog() == DialogResult.OK &&
            saveFileDialog.FileName.Length > 0)
            {
                projectStringFromFile = ""; // Clear string to save

                UISaveProject_SaveVersion();
                UISaveProject_SaveProjectType();
                UISaveProject_SaveOutputFile();
                UISaveProject_SaveFileList();
                UISaveProject_SaveOpenDump();
                UISaveProject_SaveTopModule();
                UISaveProject_SaveAddParams();

                ProjectFile_Save(saveFileDialog.FileName);

                ConsoleOut("> Project saved as : " + saveFileDialog.FileName, "Command");
            }
        }

        private void UISaveProject_SaveVersion()
        {
            string varToSave = "VER=";

            projectStringFromFile = projectStringFromFile + varToSave + progectFileVersion + "\r\n";
        }

        private void UISaveProject_SaveProjectType()
        {
            string varToSave = "TYPE=";

            projectStringFromFile = projectStringFromFile + varToSave + projectType + "\r\n";
        }

        private void UISaveProject_SaveOutputFile()
        {
            string varToSave = "OUTPUT_FILE=";

            projectStringFromFile = projectStringFromFile + varToSave + outputFileName + "\r\n";

        }

        private void UISaveProject_SaveFileList()
        {
            string varToSave = "FILE_LIST";
            string endVarBlock = "END_FILE_LIST";

            projectStringFromFile = projectStringFromFile + varToSave + "\r\n";

            for (int i = 0; i < moduleData.Count; i++)
            {
                projectStringFromFile = projectStringFromFile + moduleData[i].moduleName + "\r\n";
                projectStringFromFile = projectStringFromFile + moduleData[i].moduleFilePath + "\r\n";
            }

            projectStringFromFile = projectStringFromFile + endVarBlock + "\r\n";
        }

        private void UISaveProject_SaveTopModule()
        {
            string varToSave = "TOP_MODULE=";

            if (checkBoxUsingTopModule.CheckState == CheckState.Checked)
            {
                projectStringFromFile = projectStringFromFile + varToSave + topModuleName + "\r\n";
            }
        }

        private void UISaveProject_SaveOpenDump()
        {
            string varToSave = "OPEN_DUMP=";

            if (checkBoxHaveDump.CheckState == CheckState.Checked)
            {
                projectStringFromFile = projectStringFromFile + varToSave + dumpFileName + "\r\n";
            }
        }

        private void UISaveProject_SaveAddParams()
        {
            string varToSave = "ADD_PARAMS=";

            if (checkBoxUsingAdditionalParams.CheckState == CheckState.Checked)
            {
                projectStringFromFile = projectStringFromFile + varToSave + additionalParams + "\r\n";
            }
        }


        // File list methods

        private void UIProjectAddFileToList()
        {

            // Choose file
            if (projectType == "Verilog")
            {
                openFileDialog.Filter = "Verilog file(*.v) |*.v| All files(*.*) |*.*";
            }
            else if (projectType == "VHDL")
            {
                openFileDialog.Filter = "VHDL file(*.vhdl) |*.vhdl| All files(*.*) |*.*";
            }

            // Add to list
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ModuleData newModule = new ModuleData();

                string itemName = System.IO.Path.GetFileName(openFileDialog.FileName);

                newModule.moduleName = itemName;
                newModule.moduleFilePath = openFileDialog.FileName;

                moduleData.Add(newModule);
                AddModuleToTree(newModule);
                return;
            }

        }

        private void UIRemoveFileFromList()
        {
            RemoveModuleFromTree();
        }

        private void SaveFilesFromFileList()
        {
            for (int i = 0; i < moduleData.Count; i++)
            {
                if (moduleData[i].moduleName != "")
                {
                    for (int j = 0; j < tabControl.TabCount; j++)
                    {
                        //ConsoleOut("Tab : " + tabControl.TabPages[j].Text); //Debug

                        if (tabControl.TabPages[j].Text == moduleData[i].moduleName)
                        {
                            if (tabsData[j].tabFilePath != "NotSaved")
                            {
                                if (tabControl.TabPages[j] != null)
                                {
                                    ScintillaNET.Scintilla textBox = tabControl.TabPages[j].Controls[0] as ScintillaNET.Scintilla;
                                    ScriptFile_Save(tabsData[j].tabFilePath, textBox.Text);
                                }
                            }
                            else
                            {
                                ConsoleOut("Tab " + tabControl.TabPages[j].Name + " error : " + " No file path known (File not saved)", "Error");
                            }

                        }
                    }
                }

            }
        }


        // Project modules, tree view methods -----------------------------------------------------------

        private void AddModule(ModuleData module)
        {
            moduleData.Add(module);
            AddModuleToTree(module);
        }

        private void ClearModuleData()
        {
            moduleData.Clear();
            ClearTree();
        }


        private void ClearTree()
        {
            // Clear all
            projectTreeView.Nodes.Clear();
            

            // Add top project node
            TreeNode topNode = new TreeNode("Project");
            topNode.ImageIndex = 0;
            topNode.SelectedImageIndex = 0;
            projectTreeView.Nodes.Add(topNode);
        }

        private void AddModuleToTree(ModuleData module)
        {
            TreeNode newNode = new TreeNode(module.moduleName);
            newNode.ImageIndex = 1;
            newNode.SelectedImageIndex = 1;
            projectTreeView.TopNode.Nodes.Add(newNode);
        }

        private void RemoveModuleFromTree()
        {
            if (projectTreeView.SelectedNode != projectTreeView.TopNode)
            {
                ConsoleOut("index = " + projectTreeView.SelectedNode.Index);
                moduleData.RemoveAt(projectTreeView.SelectedNode.Index);
                projectTreeView.TopNode.Nodes.Remove(projectTreeView.SelectedNode);
            }
        }



        // Compile and run ------------------------------------------------------------------

        private void UIProgramRun()
        {
            if (projectFile == "")
            {
                ConsoleOut("> Warning : Please open project", "Warning");
                return;
            }
            else if (outputFileName == "")
            {
                ConsoleOut("> Warning : Please set output file name", "Warning");
                return;
            }
            else
            {
                if (projectType == "Verilog")
                {
                    ProgramRunVerilog();
                    return;
                }
                else if (projectType == "VHDL")
                {
                    ProgramRunVHDL();
                    return;
                }
                else
                {
                    ConsoleOut("> Error : Project type error", "Error");
                    return;
                }
            }
        }

        private void ProgramRunVerilog()
        {
            if (projectFile == "")
            {
                ConsoleOut("Please open project", "Warning");
            }
            else if(outputFileName == "")
            {
                ConsoleOut("Please set output file name", "Warning");
            }
            else
            {
                string projectFolder = System.IO.Path.GetDirectoryName(projectFile);

                //Project save
                SaveFilesFromFileList();

                ConsoleOut("> Compile: Start", "Command");

                CreateFileList(projectFolder);

                string compileParams = "-o " + projectFolder + "\\" + outputFileName + " " + "-c " + projectFolder + "\\" + "FileList";

                if (usingTopModule)
                {
                    compileParams = compileParams + " " + "-s " + topModuleName;
                }

                if (usingAdditionalParams)
                {
                    compileParams = compileParams + " " + additionalParams;
                }


                if (usingDumpFile)
                {
                    if (dumpFileName != "")
                    {
                        StartIcarusCompilator(compileParams);
                        StartVVP(projectFolder + "\\" + outputFileName);
                        StartGTKWave(@"" + dumpFileName);
                    }
                    else
                    {
                        ConsoleOut("Please set dump file name", "Warning");
                    }
                }
                else
                {
                    StartIcarusCompilator(compileParams);
                    StartVVP(projectFolder + "\\" + outputFileName);
                }
                
            }

        }

        private void ProgramRunVHDL()
        {
            
            string projectFolder = System.IO.Path.GetDirectoryName(projectFile);

            //Project save
            SaveFilesFromFileList();

            ConsoleOut("> Compile: Start", "Command");

            CreateFileList(projectFolder);



            // Analyse ===========================================================

            string fileListString = ""; // All text from file list

            try
            {
                using (StreamReader sr = new StreamReader(projectFolder + "\\FileList"))
                {
                    fileListString = sr.ReadToEnd();
                }
            }
            catch (Exception e)
            {
                ConsoleOut("Error: Can't open " + projectFolder + "\\FileList" + e.Message, "Error");
                return;
            }


            if (fileListString == "")
            {
                ConsoleOut("Error : " + projectFolder + "\\FileList" + " is empty", "Error");
                return;
            }


            ConsoleOut("- - - - - - - - - - - - - - - - - - - - - - - -  GHDL output - - - - - - - - - - - - - - - - - - - - - - - -\n");


            int cntInd = 0;
            for (int i = 0; i < moduleData.Count; i++)
            {
                string fileFromFileList = "";

                fileFromFileList = fileListString.Substring(cntInd, fileListString.IndexOf("\r\n", cntInd) - cntInd);
                //ConsoleOut(fileFromFileList); // Debug
                //ConsoleOut("st : " + cntInd + " end : " + fileListString.IndexOf("\r\n", cntInd)); // Debug

                cntInd = fileListString.IndexOf("\r\n", cntInd) + 2;



                StartGHDLAnalyse("-a " + fileFromFileList);
            }



            // Elaborate ===============================================================

            StartGHDLElaborate("-e " + outputFileName);

            //Run ====================================================

            StartGHDLRun("-r " + outputFileName + " --vcd=qwer.vcd");


            if (usingDumpFile)
            {
                if (dumpFileName != "")
                {
                    //StartGHDLCompilator(compileParams);
                    StartGTKWave(@"" + dumpFileName);
                }
                else
                {
                    ConsoleOut("Please set dump file name", "Warning");
                }
            }
            else
            {
                //StartGHDLCompilator(compileParams);
            }

            
        }

        private void UIProgramRunThis()
        {
            UIFileSave();

            int selectedTabIndex = tabControl.SelectedIndex;

            if (tabsData[selectedTabIndex].tabName.EndsWith(".v"))
            {
                string outputFile = tabsData[selectedTabIndex].tabFilePath.Replace(".v", "") + "_output";

                ConsoleOut("> Compile: Start", "Command");

                StartIcarusCompilator("-o " + outputFile + " " + tabsData[selectedTabIndex].tabFilePath);
                StartVVP(outputFile);
            }
            else if (tabsData[selectedTabIndex].tabName.EndsWith(".vhdl"))
            {
                string outputFile = tabsData[selectedTabIndex].tabFilePath.Replace(".vhdl", "") + "_output";

                ConsoleOut("> Compile: Start", "Command");

            }


        }

        private void CreateFileList(string folder)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(folder + "\\FileList"))
                {
                    string fileList = "";                 

                    // Module Tree
                    for (int i = 0; i < moduleData.Count; i++)
                    {
                        fileList = fileList + moduleData[i].moduleFilePath + "\r\n";
                    }

                    sw.Write(fileList);
                }
            }
            catch (Exception e)
            {
                ConsoleOut("Error: Can't create file list " + e.Message, "Error");
            }
        }


        // Menu ---------------------------------------------------------------------

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIFileNew();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIFileOpen();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIFileSave();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UIFileSaveAs();
        }

        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormAbout aboutForm = new FormAbout();
            aboutForm.Show();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSettings settingsForm = new FormSettings();
            settingsForm.Show();
        }



        // Main buttons ---------------------------------------------------------------------

        private void toolStripButtonNew_Click(object sender, EventArgs e)
        {
            UIFileNew();
        }

        private void toolStripButtonOpen_Click(object sender, EventArgs e)
        {
            UIFileOpen();
        }

        private void toolStripButtonSave_Click(object sender, EventArgs e)
        {
            UIFileSaveAs();
        }

        private void toolStripButtonSave_Click_1(object sender, EventArgs e)
        {
            UIFileSave();
        }

        private void toolStripButtonCloseTab_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                if (tabsData[selectedTabIndex].documentChanged)
                {
                    if (MessageBox.Show("Would you like to Close this Tab?", "Confirm", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        tabControl.TabPages.Remove(tabControl.SelectedTab);
                        tabsData.RemoveAt(selectedTabIndex);
                        if (selectedTabIndex != 0 && tabControl.TabCount != 0)
                            tabControl.SelectedTab = tabControl.TabPages[selectedTabIndex - 1];
                        else if (tabControl.TabCount != 0)
                            tabControl.SelectedTab = tabControl.TabPages[selectedTabIndex];
                    }
                }
                else
                {
                    tabControl.TabPages.Remove(tabControl.SelectedTab);
                    tabsData.RemoveAt(selectedTabIndex);
                    if (selectedTabIndex != 0 && tabControl.TabCount != 0)
                        tabControl.SelectedTab = tabControl.TabPages[selectedTabIndex - 1];
                    else if (tabControl.TabCount != 0)
                        tabControl.SelectedTab = tabControl.TabPages[selectedTabIndex];
                }
            }     
        }

        private void toolStripButtonRun_ButtonClick(object sender, EventArgs e)
        {
            UIProgramRun();
        }

        private void toolStripRunMenuRunThis_Click(object sender, EventArgs e)
        {
            UIProgramRunThis();
        }

        private void toolStripButtonRunGTK_Click(object sender, EventArgs e)
        {
            StartGTKWave("");
        }



        // Text edit buttons and menu ---------------------------------------------------------------------

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Undo();
            }
        } //Undo

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Redo();
            }
        } //Redo

        private void toolStripButton4_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Copy();
            }
        } //Copy

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Paste();
            }
        } //Paste

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Undo();
            }
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Redo();
            }
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Copy();
            }
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().Paste();
            }
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int selectedTabIndex = tabControl.SelectedIndex;

            if (selectedTabIndex != -1)
            {
                GetScintillaTextBox().SelectAll();
            }
        }



        // Tabs ----------------------------------------------------------------

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            OnTabChangeUpdateUI();
        }



        // Right panel items ----------------------------------------------------------------


        private void buttonNewProject_Click(object sender, EventArgs e)
        {
            UINewProject();
        }

        private void buttonOpenProject_Click(object sender, EventArgs e)
        {
            UIOpenProject();
        }

        private void buttonRunJustThis_Click(object sender, EventArgs e)
        {
            UIProgramRunThis();
        }

        private void buttonSaveAsProject_Click(object sender, EventArgs e)
        {
            UISaveAsProject();
        }

        private void buttonAddFileToList_Click(object sender, EventArgs e)
        {
            UIProjectAddFileToList();
        }

        private void buttonRemoveFileFromList_Click(object sender, EventArgs e)
        {
            UIRemoveFileFromList();
        }



        private void textBoxOutputFileName_TextChanged(object sender, EventArgs e)
        {
            outputFileName = textBoxOutputFileName.Text;
        }

        private void checkBoxHaveDump_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxHaveDump.CheckState == CheckState.Checked)
            {
                usingDumpFile = true;
                textBoxDumpFileName.Enabled = true;
            }
            else
            {
                usingDumpFile = false;
                textBoxDumpFileName.Enabled = false;
            }
        }

        private void textBoxDumpFileName_TextChanged(object sender, EventArgs e)
        {
            dumpFileName = textBoxDumpFileName.Text;
        }

        private void checkBoxUsingTopModule_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxUsingTopModule.CheckState == CheckState.Checked)
            {
                usingTopModule = true;
                textBoxTopModuleName.Enabled = true;
            }
            else
            {
                usingTopModule = false;
                textBoxTopModuleName.Enabled = false;
            }
        }

        private void textBoxTopModuleName_TextChanged(object sender, EventArgs e)
        {
            topModuleName = textBoxTopModuleName.Text;
        }

        private void checkBoxUsingAdditionalParams_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxUsingAdditionalParams.CheckState == CheckState.Checked)
            {
                usingAdditionalParams = true;
                textBoxAdditionalParams.Enabled = true;
            }
            else
            {
                usingAdditionalParams = false;
                textBoxAdditionalParams.Enabled = false;
            }
        }

        private void textBoxAdditionalParams_TextChanged(object sender, EventArgs e)
        {
            additionalParams = textBoxAdditionalParams.Text;
        }


        // Find Replace Dialog --------------------------------------------------------------------

        private void findAndReplaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Create instance of FindReplace with reference to a ScintillaNET control.
            findReplaceDialog = new ScintillaNET_FindReplaceDialog.FindReplace(GetScintillaTextBox());

            // Tie in FindReplace event
            findReplaceDialog.KeyPressed += MyFindReplace_KeyPressed;

            

            findReplaceDialog.ShowFind();

        }

        private void scintilla_KeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.I)
            {
                // Create instance of FindReplace with reference to a ScintillaNET control.
                findReplaceDialog = new ScintillaNET_FindReplaceDialog.FindReplace(GetScintillaTextBox());

                // Tie in FindReplace event
                findReplaceDialog.KeyPressed += MyFindReplace_KeyPressed;

                findReplaceDialog.ShowFind();
                e.SuppressKeyPress = true;
            }
            else if (e.Shift && e.KeyCode == Keys.F3)
            {
                if (findReplaceDialog != null)
                {
                    findReplaceDialog.Window.FindPrevious();
                    e.SuppressKeyPress = true;
                }
            }
            else if (e.KeyCode == Keys.F3)
            {
                if (findReplaceDialog != null)
                {
                    findReplaceDialog.Window.FindNext();
                    e.SuppressKeyPress = true;
                }
            }
            else if (e.Control && e.KeyCode == Keys.F)
            {
                    // Create instance of FindReplace with reference to a ScintillaNET control.
                    findReplaceDialog = new ScintillaNET_FindReplaceDialog.FindReplace(GetScintillaTextBox());

                    // Tie in FindReplace event
                    findReplaceDialog.KeyPressed += MyFindReplace_KeyPressed;

                    findReplaceDialog.ShowIncrementalSearch();
                    e.SuppressKeyPress = true;
               
            }
            else if (e.Control && e.KeyCode == Keys.G)
            {
                ScintillaNET_FindReplaceDialog.GoTo goToDialog = new ScintillaNET_FindReplaceDialog.GoTo((ScintillaNET.Scintilla)sender);
                goToDialog.ShowGoToDialog();
                e.SuppressKeyPress = true;
            }else if (e.Control && e.KeyCode == Keys.S)
            {
                UIFileSave();
                e.SuppressKeyPress = true;
            }
        }

        private void MyFindReplace_KeyPressed(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            scintilla_KeyDown(sender, e);
        }



        private void buttonNewProjectVerilog_Click(object sender, EventArgs e)
        {
            NewVerilogProject();
        }

        private void buttonNewProjectVHDL_Click(object sender, EventArgs e)
        {
            NewVHDLProject();
        }


    }
}
